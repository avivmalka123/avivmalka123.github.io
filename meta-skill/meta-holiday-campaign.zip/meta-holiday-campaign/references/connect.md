# Connecting Meta Ads + Ping (Step 0)

One step per message. Wait for "סיימתי" before the next. Never ask for a password, token or
key: both connectors log in on their own pages.

## §Meta · the official Meta Ads connector
Meta's official "Ads MCP Server" (part of Meta ads AI connectors, open beta).
URL: `https://mcp.facebook.com/ads`. Login is Facebook Login for Business. No Meta developer
app is needed for a regular user.

### claude.ai (web / desktop / mobile)
1. Settings (or Customize) → Connectors → "+" / "Add custom connector".
2. Name: `Meta Ads` · URL: `https://mcp.facebook.com/ads` → Add.
3. Click Connect → log in to Facebook → choose the business portfolio and the store's ad account
   → approve the permissions.
4. In this chat: "+" (or the tools/sliders icon) → Connectors → turn **Meta Ads** on.
5. Write "סיימתי".
Notes to say only if relevant:
- On the free Claude plan only one custom connector can be added. This skill needs two (Meta +
  Ping), so a paid Claude plan is needed. On Team/Enterprise an Owner must add the connector
  first.
- The connector gets the same access the Facebook user has, including client accounts. Tell an
  agency owner to pick only this store's ad account.
- Peace of mind (optional): a full-control business admin can set "ads MCP server rules" in
  Business Suite to limit what AI agents may do (for example read-only, or no budget changes).
  If he blocks budget changes, he changes budgets himself and you guide him.
If the connector was added mid-chat and its tools don't show: "פותחים צ'אט חדש וכותבים
ממשיכים קמפיין חגים". Before he goes, give his answers so far in one copyable line.

### Claude Code
Meta's documented command is for developers with a Meta app:
```
claude mcp add --transport http --client-id <META_APP_ID> meta-ads https://mcp.facebook.com/ads
```
Then `/mcp` → `meta-ads` → log in in the browser. A non-developer is better off using claude.ai.

### Verify
List the Meta tools you have, then read the ad accounts. Success = the store's ad account with
its currency. Also check: a Facebook page and (if he uses it) an Instagram account are linked,
and a payment method exists on the account (ask him to look; never handle card details).
- Login worked but the ad account isn't listed → he picked a different business portfolio, or
  isn't admin/advertiser on that account. Reconnect and choose it.
- "Access denied" on create → his role on the account is analyst/read-only. The account admin
  gives him advertiser access (Business settings → Ad accounts → people).

## §not-yet · connected, but the tools aren't enabled yet
Meta rolls the tools out gradually; some accounts connect but get few tools or read-only ones.
Say it honestly, in two lines:
"החיבור למטא עובד, אבל מטא עוד לא פתחה לחשבון שלך את הכלים לבנייה. זה בטא, והם פותחים בהדרגה.
בינתיים אני מכין לך הכול מוכן להקלקה, ותבנה את זה במנהל המודעות, צעד אחרי צעד."
Then:
- **Wait route:** check again in a new chat in a few days ("ממשיכים קמפיין חגים"). Never
  promise a date.
- **Fallback route (default during the season):** the build sheet below. Read tools that do
  work (reporting, audiences) are still used for the morning read.
Do not switch to any other ads connector or script to work around it.

## §fallback · the build sheet
A page the owner keeps open next to מנהל המודעות and clicks through top to bottom.
claude.ai: an HTML artifact. Claude Code: `~/Desktop/<brand>-meta-build-sheet.html`, opened.
Hebrew, RTL, big checkboxes, one block per object in creation order:
1. Audiences (customer lists from §audience-routes in structure.md, then lookalike).
2. Campaign: where to click, every field with the exact value (objective Sales, name from
   structure.md §naming, budget level, **leave it off / paused until the end**).
3. Each ad set: name, conversion location Website, event Purchase, pixel name, country,
   placements, audience + exclusions, the owner's budget.
4. Each ad: name, format, which media file, primary text, headline, description, CTA, link
   with UTM. Every text has a "copy" button.
5. The preflight checklist (structure.md §preflight), then "only now: publish, and keep the
   campaign off until you decide".
After he builds, ask him to write "בניתי"; if the read tools work, verify names, exclusions
and status against the sheet and point out any mismatch.

## §media · images and videos
Guides report that the connector can't upload local image or video files. So:
- If the connector can use media already in the ad account library, or an image URL from the
  product page, use it.
- Otherwise give the clicks: open the paused ad → Media → Add media → Upload → pick the file →
  check the 1:1 / 4:5 and 9:16 crops → Save (don't publish the campaign on).

## §Ping · the Ping AI connector (customer segments)
Ping AI is a Hebrew marketing system for stores (email, WhatsApp, SMS) that also keeps live
customer segments. Ping doesn't run ads; here it's the source of the audiences and the
follow-up after the click (migrate.md). Why it's recommended: opening.md.
1. Install: Shopify → https://apps.shopify.com/ping-ai → Install → approve → short onboarding.
   Other platforms: https://pingai.org → sign up → connect the store. There is a free plan to
   start; if a segment tool is limited on it, say so plainly.
2. claude.ai: Settings → Connectors → "Add custom connector" → Name `Ping` · URL
   `https://pingai.org/api/mcp` → Add → Connect → log in with the store's account → Allow →
   turn it on in this chat → "סיימתי".
   Claude Code: `claude mcp add --transport http ping https://pingai.org/api/mcp` → `/mcp`.
3. Verify: `listMyStores` returns the store. Several stores → ask, then `selectStore`. Run
   `syncOrderHistory` once if buyers show 0 on a store that has orders.
Stuck: unauthorized = logged into a different Ping account; no tools = connector not on in this
chat; empty store list = the install didn't finish. Ping's support (offers.md) can help.

## §no-Ping · the owner doesn't want Ping
Continue, without pushing again. Skip Steps 3 and 5. Buyers for exclusion come from the
store's own export: Shopify admin → Customers →
filter "Amount spent > 0" → Export → CSV for the current filter. Warm audiences come from what
Meta builds itself (site visitors, Instagram/Facebook engagers). Say the one-line trade-off:
"זה עובד, אבל הרשימה קפואה ליום הייצוא. כל קונה חדש בחגים ימשיך לראות מודעות לקהל חדש עד
שתייצא שוב".
