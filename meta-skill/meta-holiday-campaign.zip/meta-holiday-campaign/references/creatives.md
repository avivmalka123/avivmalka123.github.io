# Creatives: angles, hooks and copy (Step 5)

## Read first, write second
Sources, in this order: the product page (title, description, images, price, variants),
`searchProducts` / `getProductInsights` (what sells, bought-together), `getPolicies`
(shipping, returns), real reviews on the page, the owner's answers. Write down 5–8 true facts
about the product before writing a word of copy. Every claim in an ad must point to one of
them. Unknown = leave it out.

## An angle is a different reason to buy, not a different picture
3–5 per ad set, each from a different row. Two ads that say the same thing with another photo
are one angle.
| Angle | The question it answers | Example hook (Hebrew, fill with real facts) |
|---|---|---|
| pain | what's annoying today without it | "כל בוקר אותו בלגן עם {הבעיה}?" (about the situation, never about the person's body or identity) |
| result | what life looks like with it | "{תוצאה מוחשית} בתוך {זמן אמיתי מהעמוד}" |
| proof | who already uses it | "{מספר אמיתי} ביקורות, ממוצע {X}" (only real numbers from the page) |
| how | how it works / why it's different | "3 שניות, בלי {הטרחה הרגילה}" |
| objection | the reason people hesitate | "לא בטוחים במידה? החלפה חינם תוך {ימים מהמדיניות}" |
| gift | for whom it's a gift (Hanukkah) | "מתנה לחנוכה למי ש{תיאור}" |
| offer | the real offer + real end time | "בלאק פריידיי: {X}% עד {יום ושעה אמיתיים}" |
PROS test: start with pain / result / how / proof / gift. WARM: objection / offer / proof /
reminder ("השארת משהו בעגלה" style, without saying you know what they did: write "עוד חושבים
על זה?", not "ראינו שנטשת").

## Each ad
- **Hook**: the first line of the primary text and the first 3 seconds of a video. The whole
  ad rises or falls on it. Concrete, about the customer's situation, no greetings.
- **Primary text**: the first ~125 characters are what most people see; put the point there.
  2–5 short lines total. One emoji at most per line, none is fine.
- **Headline**: short (about 40 characters or less), the benefit or the offer.
- **Description**: one short line (shipping, returns, proof). Often hidden; never the key info.
- **CTA**: "לקנייה" (Shop now) for sales; "מידע נוסף" (Learn more) for the teaser.
- **Media brief** per ad: which real photo / video from the store, what the first frame shows,
  any text on the image (short, Hebrew, readable on a phone), formats 1:1 or 4:5 and 9:16.
  Video first if the owner has any: a phone video of the product in use usually beats a
  studio photo. Don't ask Claude-generated images to show the product doing things it doesn't.
Show the owner one compact card per ad: angle · hook · headline · media · CTA.

## Offers and prices
- An offer appears only if the owner confirmed it exists in the store, with its real dates.
- Never above the owner's max discount. "עד X%" only if X% truly exists on real items.
- A "was" price must be a real price the store recently charged. No invented reference prices.
- A deadline is written only if it's real, and the ad is paused when it passes.
- Free shipping / gift with purchase: only if the owner set it up.

## §policy · what Meta (and fairness) won't allow
- **Personal attributes:** never imply you know the reader's health, weight, age, religion,
  ethnicity, sexual orientation, finances, pregnancy, disability or criminal record. ✗ "נמאס
  לך מהקמטים שלך?" ✓ "קרם לילה עם {רכיב אמיתי}". ✗ "גם את סובלת מכאבי גב?" ✓ "כרית שבנויה
  לתמיכה בגב בזמן שינה".
- **Health, weight, skin, supplements:** no before/after images, no "תוצאות מובטחות", no
  "מרפא", no "תרדי X קילו". Describe the product, not a medical result.
- **No fake urgency or scarcity:** no countdown to nothing, no "נשארו 3" unless the store shows
  that number.
- **No misleading buttons or images** (fake play buttons, fake notifications).
- **Claims must match the landing page.** If the page doesn't say it, the ad doesn't.
- Brand names of others, celebrities, and testimonials: only with rights and only real.
If Meta rejects an ad: read the reason the connector returns, explain it in one line, propose
a compliant rewrite, and ask before resubmitting.

## Language
Hebrew that sounds like a person, not a translation: short sentences, everyday words, the
store's tone (ask once: "יותר מצחיק או יותר רציני?"). Gender: plural ("אתם"), or the form
the store already uses. Spell-check names, sizes and numbers against the page.
