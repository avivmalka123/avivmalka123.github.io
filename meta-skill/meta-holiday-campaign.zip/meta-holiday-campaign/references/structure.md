# The 2026 test structure

The goal of a test is not "to sell at any price". It's to learn, fast and cheaply, which
audience + angle brings purchases at a cost the store can live with, before the most
expensive weeks of the year. Everything below serves that.

Meta's screens change often. When a field below isn't where it's described, read what the
connector / screen actually offers and pick the option with the same meaning. Never claim a
setting exists that you didn't see.

## §tracking · check before building (Step 2)
1. A pixel (in 2026 Meta calls it a "dataset") exists and is connected to the ad account.
2. A **Purchase** event was received in the last 7 days, with value and currency.
3. Server events (Conversions API, "חיבור ישיר מהשרת למטא") are on, so purchases still reach
   Meta when the browser blocks the pixel.
4. Meta's purchases for a recent week vs. the store's orders (`getStoreSales`). A gap is normal;
   say the size plainly ("מטא רואה בערך 8 מתוך 10 הזמנות"). A huge gap = fix first.
Use the connector's dataset / signal diagnostics tools if you have them. Otherwise the owner
opens Events Manager → Data sources → his pixel → Overview, and reads you the Purchase line.

### §tracking-fix (Shopify)
Shopify admin → Apps / Sales channels → **Facebook & Instagram** (Meta's app) → Settings →
Data sharing → turn it on and pick the highest level offered (it includes the server
connection) → choose the same pixel the ad account uses → Save. Then a real test purchase
(or a low-value order he cancels) and check Events Manager for Purchase within the hour.
Other platforms: their official Meta integration; same checks.

## §audiences
| Audience | Source | Used in | Why |
|---|---|---|---|
| Buyers (all past buyers) | Ping segment "buyers" | **excluded** from the new-audience ad set | don't pay to reach people who already bought |
| Abandoned carts | Ping segment / carts | warm ad set | closest to buying |
| Viewed, didn't buy | Ping segment (viewed product, not bought) | warm ad set | showed interest |
| VIP / repeat buyers | Ping segment (3+ orders, or the store's own VIP rule) | lookalike seed; early access in the warm ad set | best customers → find similar people |
| Site visitors 30 days, IG/FB engagers 30 days | Meta builds them from the pixel / page | warm ad set | free warm audiences |
Warm ad set excludes buyers of the last 30 days, unless the ad is the VIP early-access ad.
Lookalike: 1%, Israel. Meta treats it as a hint when broad / Advantage+ audience is on; say so.
Meta needs at least 100 matched people in one country for a lookalike source; a tiny
seed is weak: skip it and say why.

### §audience-routes · getting a Ping segment into Meta (best first)
1. **The Meta tool creates the customer list.** If the connector has a tool that creates a
   customer-list custom audience and adds members: confirm with the owner first, send only
   the fields Meta uses (email, phone in 972 format, first name, last name, country), and let
   the tool handle hashing per its schema. If Meta asks to accept the Custom Audience terms,
   only the owner can do that: give him the link and wait.
2. **Export from Ping**, if the segment screen in Ping offers an export: the owner downloads
   the CSV, then step 4.
3. **A file Claude prepares** from Ping's customer tools for that segment: a CSV with columns
   `email,phone,fn,ln,country` (phone `9725XXXXXXXX`, country `IL`). Created as a file to
   download, never pasted in the chat.
4. **Upload in מנהל המודעות**, one step per message: Audiences → Create audience → Custom
   audience → Customer list → Next → upload the file → check the columns are matched (email,
   phone, first name, last name, country) → name it per §naming → Upload and create. Wait for
   "סיימתי"; the match takes up to a few hours.
Before any list leaves the store, one line: "הרשימה עולה רק לחשבון המודעות שלך, ומטא מצפינה
אותה. ודא שמדיניות הפרטיות של החנות מאפשרת פרסום ללקוחות". The owner decides.
Lists are frozen on the day they're made: refresh the buyers list before Black Friday and
before Hanukkah (one line reminder in the morning read).

## The campaign
- **One campaign**, objective **Sales**, conversion location **Website**, event **Purchase**.
- Two ad sets so the owner sees new vs. warm separately: if the screen offers an Advantage+
  sales setup that blocks separate ad sets or exclusions, use the manual setup (turn
  Advantage+ campaign off); if it offers an account-level "existing customers" setting, put
  the buyers list there too.
- Budget at the ad-set level during the test, so each audience gets its share and the owner
  controls the split.
- Country: where the store ships (usually Israel). Language: no restriction needed; the copy is
  Hebrew. Age/gender: open unless the product is truly for one group (owner decides).
- Placements: Advantage+ placements (automatic), with media in 1:1 or 4:5 and 9:16.
- Attribution: the default (7-day click, 1-day view) unless the owner chose otherwise.
- Link: the product / collection page with UTM `utm_source=meta&utm_medium=paid&utm_campaign=hol26`.

### Ad set 1 · PROS (new audience)
Broad Israel (Advantage+ audience on), lookalike as a hint if it exists. **Excludes buyers.**
3–5 different angles (creatives.md). No discount needed in every ad; the main days add the offer.

### Ad set 2 · WARM (knows the store)
Abandoned carts + viewed-not-bought + site visitors 30d + engagers 30d. Excludes buyers of the
last 30 days. 3–5 angles: reminder, objection, offer, proof, VIP early access (shown only to
VIP during early access).

### §budget · the owner's number
Never invent it. Explain the trade-offs in plain words and ask:
- Meta's help center has long said an ad set leaves its learning phase after about 50
  purchases in 7 days (the ad set's "Learning" status shows the current state). A small
  budget will usually stay "learning" longer; that's normal, not a failure.
- A common rule of thumb (not a promise): enough daily budget per ad set to pay for about one
  purchase a day at his target cost (daily.md §target). If his number is below that, say what
  it means: slower answers, decide on clicks and add-to-carts first, purchases later.
- A common starting split (his choice): most to PROS, a smaller part to WARM, because the warm
  audience is small.
Show: per day, per week (×7), and until 31.12 (× days left). Then: "על איזה סכום ליום סוגרים?".

## §naming
Short, sortable, the same everywhere, English letters (the owner can read them):
- Campaign: `HOL26 | SALES | TEST | <DD.MM start>`
- Ad set: `HOL26 | PROS | IL | broad | ex-buyers` · `HOL26 | WARM | carts+viewed+site30 | ex-buy30`
- Ad: `<phase> | A<n>-<angle> | <format> | v<n>` e.g. `TEST | A1-pain | vid-9x16 | v1`,
  `BF-main | A4-offer | img-1x1 | v1`. Phases: TEST, TEASE, EARLY, BF-main, LAST, HAN, EOY, POST.
- Audiences: `HOL26 | Ping | buyers | <DD.MM>`, `HOL26 | LAL 1% IL | VIP | <DD.MM>`.
The date in the audience name tells the owner when the frozen list was made.

## Status rule
Created = PAUSED. After each create, read it back; if anything shows ACTIVE, pause it at once
and tell the owner. Activation follows SKILL.md Hard rule 1 only.

## §preflight · before the owner turns it on
- [ ] Purchase event seen in the last 7 days
- [ ] Buyers excluded in PROS (name of the list shown)
- [ ] 3–5 ads per ad set, each a different angle, each previewed in feed and reels
- [ ] Every offer in the ads exists in the store, under the max discount, with the real dates
- [ ] Link opens the right page on mobile, UTM present
- [ ] Budget per ad set = the owner's numbers; total per day and per week shown
- [ ] Payment method on the ad account (the owner checked)
- [ ] Everything still PAUSED

## §calendar · the 2026 season (Israel)
Count from today. Dates: Black Friday Fri 27.11.2026 · Cyber Monday 30.11 · Hanukkah from the
evening of 4.12 to 12.12 · end of year 31.12. No ⛔ no-marketing days fall in this window.
| Phase | When | What runs | Offer |
|---|---|---|---|
| TEST | as soon as tracking passes, ideally 7–10 days before BF | PROS + WARM, 3–5 angles each, no or small offer | none / owner's evergreen offer |
| TEASE | ~5–7 days before BF | add a teaser ad in WARM ("משהו מגיע ב־27.11") | none |
| EARLY | ~3 days before BF (24–26.11) | early-access ad to VIP / warm | the BF offer, early |
| BF-main | 27.11–30.11 | swap in offer ads in both ad sets; keep the 1–2 best test angles | BF offer (≤ max) |
| LAST | 30.11 (Cyber Monday), end of day | last-chance ad in WARM | same offer, real end time |
| HAN | from ~1.12 gift angle; 4.12–12.12 | gift ads; **shipping cut-off** ad in WARM | Hanukkah offer (≤ max) |
| EOY | 13.12–31.12 | "the best sellers of 2026" angle, no new discount unless the owner wants | owner's choice |
| POST | from 1.1.2027 | pause expired offers; PROS back to non-discount angles; WARM: holiday buyers get a second-order angle | none / small |
Shipping cut-off: the last day to order and still receive it before the last night of Hanukkah
= 12.12 − shipping days (Q4) − one day of margin. Only say a date you calculated from his days.
Before every swap: duplicate as PAUSED, show, owner approves (SKILL.md Step 9). Big edits to a
running ad set usually restart learning, so prefer adding new ads over editing live ones, and
make changes before a weekend, not in the middle of BF weekend.

### §shabbat
Meta keeps ads running on Shabbat by default. If the store pauses on Shabbat: the owner pauses
by hand on Friday afternoon and turns on after Shabbat, or (only with a lifetime budget) uses
ad scheduling. Ask once; don't assume either way. BF 27.11 is a Friday: say it.

## §after · after the season
- Pause every ad whose offer ended. No ad keeps a sale that doesn't exist.
- Refresh the buyers list (new holiday buyers) and keep it excluded from PROS.
- The winners (angle + audience) become the evergreen campaign for January; the owner decides
  the budget again.
- A one-page summary: spend, purchases, cost per purchase, best angle, what we learned. Only
  real numbers.
