# The morning read (Step 10)

Triggers: "בוקר מטא", "מה קרה אתמול", "איך הקמפיין", or a scheduled run. **Read-only.**
Recommend; execute only what the owner approves in this chat, one action at a time.

## §target · "עלות לרכישה שעוד משתלמת"
From the owner's answer to Q5 (profit per order, after product and shipping): that number is
his break-even cost per purchase. Say it as: "כל עוד הזמנה עולה לך במודעות פחות מ־₪{X},
אתה מרוויח עליה". If he didn't know: use the store's average order (`getStoreSales`) only to
show the question, never to invent his margin; after week 1 ask again with his real numbers.
Never assume a margin percentage.

## What to read
Yesterday, and since the test started, per campaign → ad set → ad (the connector's reporting
tools):
| Number | Say it as | Why it matters |
|---|---|---|
| spend | "הוצאת" | vs. the budget he set |
| purchases + purchase value | "הזמנות שמטא ייחסה למודעות" | the goal |
| cost per purchase | "כל הזמנה עלתה" | vs. his break-even |
| ROAS | "כמה שקלים חזרו על כל שקל" | quick health |
| link CTR | "כמה מתוך הרואים לחצו" | is the hook working |
| CPM | "מחיר לאלף צפיות" | holiday weeks usually get more expensive |
| frequency | "כמה פעמים כל אחד ראה" | warm audiences get tired |
| add to cart / checkout | "הכניסו לעגלה / הגיעו לקופה" | early signal when purchases are few |
| learning status, delivery issues, rejected ads | as-is in plain words | blockers |
Plus the store's own orders yesterday (`getStoreSales`) next to Meta's number, so he sees
both ("מטא ייחסה 6, בחנות היו 9 הזמנות").
If the Step 5 Ping flows are on: one line from `getAutomation` stats (sent, bought after) for
"הגיע לקופה" and "צפה במוצר" ("אחרי הלחיצה: פינג החזירה אתמול {n} הזמנות מעגלות"). Real numbers
only; nothing on = skip the line.

## How to say it (max 8 lines)
```
בוקר טוב · יום 4 לטסט
אתמול: הוצאת ₪{spend} · {n} הזמנות · כל הזמנה עלתה ₪{cpp} (היעד שלך: עד ₪{X})
מתחילת הטסט: ₪{spend} · {n} הזמנות · על כל שקל חזרו {roas} ₪
הכי טוב: {ad name} · {why in plain words}
הכי חלש: {ad name} · {why}
בחנות אתמול: {orders} הזמנות (מטא רואה רק חלק, זה תקין)
ההמלצה שלי: {1–3 actions, each with the reason}
מאשר? (תכתוב את מספר ההמלצה)
```
Too early to judge → say so: "עוד מוקדם. אחרי ₪{X} הוצאה למודעה נדע יותר".

## Recommendation rules of thumb (say they are rules of thumb, not laws)
All thresholds come from his break-even (X), never from invented benchmarks.
- **First 48–72 hours:** don't touch unless something is broken (no delivery, rejected ad,
  wrong link, a spend spike). Meta is still learning.
- **Pause an ad:** it spent about 1.5× X with no purchase, after at least 2 days.
- **Replace an angle:** its link CTR is clearly lower than the other ads in the same ad set
  after a few thousand impressions. Compare inside the account, not to "the market".
- **Raise budget (owner's approval, his number):** an ad set under X per purchase for 3 days,
  with several purchases, not in the middle of BF weekend. Common practice: steps of about
  20% so learning isn't reset; he decides the amount.
- **Refresh creative in WARM:** frequency climbing (around 4+ in a week) and CTR falling.
- **Before each holiday phase:** remind the swap (structure.md §calendar) and the buyers-list
  refresh.
- **Spend > the daily budget he set, or a sudden jump:** tell him first, recommend pausing.
Never: change targeting, budgets or status on your own; "fix" by creating new campaigns he
didn't ask for; declare a winner from 1–2 purchases ("כיוון בלבד, ממשיכים לבדוק").

## Scheduling
- Claude Code: offer a daily scheduled task (e.g. 08:30) that runs this read and saves it;
  read-only.
- claude.ai: "כל בוקר תכתוב לי 'בוקר מטא'".
