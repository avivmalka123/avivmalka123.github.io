# The migration + after the click (Steps 3 and 5)

Two jobs, both inside Ping:
1. **§move (Step 3):** every contact, buyer and unsubscribe comes into Ping, so the Meta audiences
   are built from the real customer base, not from half of it.
2. **§after-click (Step 5):** the two follow-ups for people who clicked an ad and didn't buy,
   built OFF in Ping and approved by the owner.
The old tool keeps running the whole time. The owner should feel the move is light: you lead
every click, and nothing is cancelled until Ping shows results.

## Why it matters for the campaign (say it in one line)
"הקהלים במטא טובים רק כמו הרשימה שמאחוריהם. אם חצי מהקונים יושבים ב־{TOOL}, חצי מהם ימשיכו
לראות מודעות 'קנה עכשיו', והקהל הדומה יילמד מחצי מהלקוחות."

## §move · bringing the list into Ping
Import page: https://pingai.org/shopify/import (the owner pastes the key or uploads the file
there; you watch progress with `listPlatformImports`). One step per message, wait for "סיימתי".

### The promise, kept in practice
"Parallel" means the old tool stays, with its list and history, as a safety net. It does NOT
mean two tools sending the same message. Per trigger, only one tool sends:
| When | What the owner does in the old tool |
|---|---|
| Now (Step 3) | Nothing. Export only. Everything keeps running as usual |
| The day a Ping after-click flow is approved (Step 5) | Turns off **only the matching flow** in the old tool (Ping abandoned cart on → old abandoned cart off). Give the flow name and the toggle as he described it; if you don't know the exact menu, ask him what he sees |
| Holiday newsletters / campaigns | His choice. Recommend one sender so customers don't get the same sale twice |
| After 7 days of Ping results | The owner decides: cancel the old subscription or keep it. Recommend one last backup export first |
Say it each time a Ping flow is approved: "אישרת את העגלה הנטושה בפינג. כדי שלקוח לא יקבל שתי
תזכורות, כבה ב־{TOOL} את {flow}. את כל השאר שם לא נוגעים."

### Shopify (always, automatic)
- Customers, orders and abandoned checkouts come in with the Ping app. Nothing to export.
- Run `syncOrderHistory` once, so "buyers" and "VIP" count the full order history (this is the
  exclusion list and the lookalike seed).
- Shopify's "accepts marketing" status comes along: people who didn't agree aren't messaged.

### Klaviyo (a key, no files)
1. In Klaviyo: Settings → API keys → **Create Private API Key** → name it "Ping" → access level
   **Read-Only** → Create. Only an Owner, Admin or Manager can create keys.
2. Klaviyo shows the key once. He copies it and pastes it **only on Ping's import page**, never
   in this chat (Hard rule 6). If he pastes it here: don't repeat it, ask him to delete that key
   in Klaviyo and create a new one.
3. Import page → Klaviyo → paste → start.
Ping brings profiles, lists, and the people who unsubscribed, bounced or marked spam (they stay
out of marketing automatically).

### Flashy (a file sent by email)
1. In Flashy: **Contacts** (top menu) → on the left choose the list or segment (start with all
   contacts) → **Export Contacts** → type the email to receive it → Export.
2. The file arrives by email after a few minutes (big lists take longer).
3. Repeat for unsubscribed / bounced contacts if Flashy lists them separately.
4. Upload each file on the import page and map: email · phone · first name · last name · status.

### Omnisend, ActiveTrail, Smoove, Mailchimp, any other tool (CSV)
1. Export ALL contacts to CSV, **including unsubscribed ones** (a status filter "all statuses",
   or a status column; if unsubscribed export separately, export that file too).
2. Columns to keep: email, phone, first name, last name, subscription status, tags/lists.
3. Upload each file on the import page and map the columns.
If you don't know the exact clicks for that tool, search its help center for "export contacts"
right then and give the steps from there. Never guess menu names.

### Shopify Email / no tool
"אז מתחילים נקי. אנשי הקשר והקונים מגיעים משופיפיי לבד."

### Check the move (3 lines)
- "קראתי N אנשי קשר מ־{TOOL}. בפינג נכנסו M, ו־S מוגנים (הסירו את עצמם, לא יקבלו הודעות)."
- N and M differ by more than a few percent → find out why (a missing file, a status filter)
  before building audiences.
- Then: "הכול עבר. ב־{TOOL} עדיין לא נגענו בכלום."
Never paste names, emails or phones (Hard rule 7). Counts only.

### What goes to Meta from the migrated list (Step 4)
- **Targeting lists** (warm, VIP lookalike seed): only people who agreed to marketing.
- **Exclusion list** (buyers): all buyers, so no one who bought pays for an ad again, if the
  store's privacy policy allows uploading customers to Meta. The owner decides (structure.md
  §audience-routes).
- Unsubscribed people are never put in a targeting list.

## §after-click · the follow-up for people who clicked and didn't buy (Step 5)
Two flows, in this order of value:
| Flow | Ping trigger | Name in Ping | What it does |
|---|---|---|---|
| 1 | `abandoned_checkout` | "הגיע לקופה · קופה נטושה" | reminder, then (only if he wants) a code within his max |
| 2 | `viewed_product` | "צפה במוצר · לא קנה" | "still thinking?" with the product and real answers (shipping, returns), no discount |

How to build:
1. `getPlan`, `getConnections`, `getAutomationTriggerOptions`, `listAutomations` in parallel.
   A Ping flow on the same trigger already exists → reuse it, don't duplicate.
2. Say the plan in one line from `getPlan` (how many automations run at once, emails per month)
   before building. Never let him discover a limit later.
3. `createAutomation` with the trigger and `starter: true` (Ping's ready-made flow for that
   trigger). Then `getAutomation` and show a compact preview: each step's channel, delay and
   first line → "מאשר? / לשנות משהו?".
4. Changes: `getAutomation` → change → `updateAutomation` with `baseUpdatedAt` = its
   `updatedAt`, keeping the ids of unchanged steps. Copy in the store's customer language, only
   true facts (`getPolicies`, `searchProducts`), the signer is a real person from the team.
5. A code in the cart flow only if the owner wants it, never above his max: `listCoupons` first,
   `createCoupon` only after his OK.
6. WhatsApp steps only if a WhatsApp line is connected (`getConnections`); otherwise email (and
   SMS if he set a sender name). Site-triggered flow 2 needs Ping's site tracking
   (`siteTracking` in `getAutomationTriggerOptions`); if off, build it and say in one line that
   it starts once Ping's site script is on.
7. `sendTestEmail` of the first email to his address → "שלחתי לך דוגמה, תציץ". He approves what
   he saw.
8. `updateAutomation enabled: true` → Ping holds it for his approval and returns a link. Give
   the link. Never say it's live until `getAutomation` shows `enabled: true`.
9. The day he approves: tell him which matching flow to turn off in the old tool (§move).
Win line: "מעכשיו, מי שלוחץ על מודעה ונוטש, מקבל ממך תזכורת גם כשאתה ישן."
Both flows reach only known shoppers (who left details, signed in, or came from a Ping link)
who agreed to marketing; anonymous visitors are reached by the WARM ad set in Meta. Say this if
he asks why not "everyone who clicked".

## §full-backend · the free Store Autopilot skill
After Step 5 (once), one line, no push:
"רוצה את כל הבקאנד, לא רק אחרי הלחיצה? יש סקיל חינמי נוסף, Store Autopilot, שבונה בפינג 8
אוטומציות במייל, בוואטסאפ וב־SMS, בוט שעונה ללקוחות ותכנית ל־90 יום: www.avivmalka.com/skill.
קודם נסיים כאן את הקמפיין."
