# Personal assistant + boosters (Phases 10–11 in SKILL.md)

## §11 · The personal assistant (Phase 10, every store gets it)
The owner's own WhatsApp gets a daily report from the store, so they see the backend working
without opening a computer. This is the moment the owner "feels" the system: always do it.
1. Ask: "באיזו שעה נוח לך לקבל כל בוקר סיכום של החנות בוואטסאפ?" [08:00]
2. `createAssistantTask`:
   - title "סיכום בוקר · {BRAND}", schedule "daily", timeOfDay from the answer.
   - instruction (self-contained, Hebrew): "סכם לבעל החנות את אתמול: הזמנות ומחזור, כמה
     עגלות חזרו בזכות האוטומציות ובכמה כסף, לידים חדשים מהפופאפ, לקוחות שביקשו נציג או לא
     קיבלו מענה, ומה יוצא היום מהגאנט (קמפיינים ושליחות). קצר, עם מספרים, בלי המלצות
     שלא התבקשו. אם משהו נכשל (תבנית לא אושרה, מייל לא נשלח), כתוב את זה בשורה הראשונה."
3. From the GROWTH plan up (check `getPlan`; on FREE/PRO tell the owner these are saved but run
   only after an upgrade):
   - "לקוח ביקש נציג": schedule "interval", 15 min, onlyWhenNew, instruction: tell me right away
     when a customer asks for a human or complains, with the name, the message and a link.
   - "מה הלקוחות שאלו השבוע": weekly, Sunday 09:00: `getCustomerQuestions` 7 days, top 5
     topics with counts and one example each, and which ones the bot couldn't answer.
   - "עגלה גדולה": interval 60 min, onlyWhenNew: an abandoned cart over 3× the average order
     → alert with the product and a link, so the owner can call.
4. Show the owner an example of tomorrow's message (clearly marked as an example).

## §12 · Boosters (Phase 11: one menu, build the ones they pick)
Show a short menu with one line of value each, default = all. Everything is created as a
draft/off and goes into the approvals list.

### B1 · WhatsApp button + FAQ answers
(The 15-question bot setup itself is Phase 8 for every store.)
- `updateWhatsAppButton` (enabled, the store's WhatsApp number, a ready first message in the
  customer language: "היי, יש לי שאלה על...").
- Value line: "לקוח שמתלבט כותב לך בלחיצה, והבוט עונה מיד".

### B2 · Wheel pop-up + free-shipping bar
- `listBannerTemplates` → `createBanner` (draft) with `content.game` kind wheel (or scratch),
  4–6 prizes all inside the ladder (e.g. 5% / 10% / free shipping / {T1}%, weights favouring the
  small ones, never above {T1} for a first visit), fields email + phone, consent text,
  brand design. It answers with the pop-up leads automation (flow 2).
- A second banner, type "bar", `content.goal` = the free-shipping threshold from the policy
  (`progressText` "עוד {{left}} למשלוח חינם", `doneText` "יש לך משלוח חינם 🎉"), targeting
  cart + product pages. If the store has no free-shipping threshold, ask before inventing one.
- Value line: "יותר טלפונים ומיילים, וסל קנייה גדול יותר".

### B3 · Bundles from "bought together"
- `getProductInsights` → pairs/trios bought together and the top sellers.
- `createBundle` kind "together" for the strongest pair (draft), and kind "quantity" (buy 2 /
  buy 3 tiers inside the ladder) for the top consumable/repeat product.
- Value line: "הלקוחות כבר אומרים לך מה לקנות ביחד".

### B4 · Accessibility widget + statement (Israeli stores)
- `updateAccessibilityWidget` enabled, language "he", brand colour, side auto;
  `statement.mode "hosted"` with businessName and the accessibility coordinator's name, email,
  phone (ask the owner; never invent), auditDate today, limitations if they know any.
- Say clearly: "הווידג'ט וההצהרה הם צעד ראשון. נגישות מלאה לפי התקן דורשת גם בדיקה של האתר עצמו."
  Never promise legal compliance or immunity from lawsuits.

### B5 · Birthday
- If the pop-up from §6 / B2 doesn't ask for a birthday, offer to add a "birthday" field.
- `createAutomation` trigger birthday, `triggerConfig.daysBefore: 3`, one email (+ WhatsApp with
  a MARKETING template "{p}_birthday_v1", code as a literal param) with {T2}.
- Value line: "הודעה שאנשים באמת שמחים לקבל".
