# Copy library · English customers

Voice: a real person from a small team, warm, plain, short sentences. No fake urgency.
Adapt to the brand's world and real products/policies. `[[...]]` = fill from real data or drop.

## Emails
### 1 · Checkout abandon
- **E1 · 1h** · "We saved your {{product}}" / "It's still here, one tap away" · H: "Your order
  didn't go through" · "Everything is saved exactly as you left it. If something stopped you,
  size, shipping or anything else, just reply to this email." · Button "Finish my order" ·
  list: [[ships in X days]] · [[X-day easy returns]] · "Real people answer"
- **E1b (A/B personal note, email-only)** · "Quick question from {SIGNER}" · plain text:
  "Hi {{name}}, {SIGNER} from {BRAND} here. I saw you started an order for {{product}} and didn't
  finish. Can I ask what held you back? I read every reply myself. If it's just timing,
  everything's saved here: {{cart_link}}"
- **E2 · 24h · {T2}%** · "{T2}% to make it an easy yes" · code {PFX}BACK{T2}
- **E3 · 3d · {T3}% last** · "Our last code for this cart" · "We won't email about this cart
  again. If you still want it, this is the moment: {T3}% with {PFX}LAST{T3}." + 3 short FAQs.

### 2 · Pop-up leads
- **W1a code first** · "Your code is inside: {{coupon}}" · "Welcome to {BRAND}" · 3 bestsellers.
- **W1b story first** · "Nice to meet you, I'm {SIGNER}" · the real story in 3 short paragraphs → code.
- **W2 day 2** · "Where most customers start" · the #1 product + why.
- **W3 day 5** · "What people ask us before buying" · 3–4 real Q&As.
- **W4 day 9** (real reviews only) · "Don't just take our word for it".
- **W5 day 14** · "Your code is still active" · "Last note about it, we won't crowd your inbox."

### 3 · Product view
- **V1** "Still thinking about {{product}}?" · 3 real reasons · **V2 day 1** "Everything you
  wanted to ask" · **V3 day 3** "What others picked this week".

### 4 · After purchase
- **O1** "Thank you, {{name}}. Here's what happens next" · packing → tracking → [[X]] days ·
  "Questions? Just reply." · **O2 day 10** "Did it arrive? All good?"

### 5 · Second order · **S1** "What goes great with your {{product}}" (no code) · **S2** "{T2}% off your second order".
### 6 · Win-back · **WB1** "It's been a while, a lot is new" · **WB2** "{T3}% to welcome you back" · **WB3** "A last reminder about your code".
### 7 · Came back · **R1** "Good to see you back" + {T2}% · **R2** "This month's bestsellers".
### 8 · VIP · **VIP1** "You're one of our best customers" (thanks, no code) · **VIP2** "A code only insiders get" · **VIP3** "Last days for your insider code".

## WhatsApp templates (language "en")
Footer "{BRAND} · Reply STOP to opt out". Header without emoji.
- **{p}_checkout_saved_v1** · "Your cart is saved" · "Hey {{1}}, {SIGNER} here from {BRAND} 👋
  Looks like your checkout didn't go through, so I saved your {{2}} for you. You can finish in
  one tap below. Not sure about size, shipping or returns? Just reply to this message. A real
  person from our team answers." · URL "Finish my order" · QR "I have a question"
- **{p}_checkout_question_v1** · "Quick question" · "Hey {{1}}, {SIGNER} from {BRAND} here.
  I noticed you didn't finish checking out the {{2}}. Can I ask what held you back?
  Tap the answer that fits best and I'll help you right here in the chat." · QR "The price" ·
  "Shipping time" · "Size or fit question" · "Something else"
- **{p}_checkout_offer_v1** · "{T2}% off is waiting for you" · "Hey {{1}}, your {{2}} is still
  in your cart. To make it an easy decision, here's {T2}% off your whole order with code *{{3}}*.
  Tap the button below and it's already applied. Questions? Just reply." · URL "Claim my {T2}% off" · QR "I have a question"
- **{p}_browse_v1** · "Still thinking it over?" · "Hey {{1}}, {SIGNER} from {BRAND} here.
  I saw you checking out the {{2}} earlier and wanted to make sure you didn't lose it. Got a
  question about sizing, fit or shipping? Just reply and I'll answer personally." · URL "Take another look" · QR "I have a question"
- **{p}_order_confirmed_v1** (UTILITY) · "Order confirmed" · "Hi {{1}}, thank you for your order
  {{2}} from {BRAND}. We've received it and our team is getting it ready. You'll get a tracking
  number as soon as it ships. Need to change something? Reply to this message." · QR "Question about my order"
- **{p}_order_arrived_v1** (UTILITY) · "Did your order arrive?" · "Hi {{1}}, it's the {BRAND}
  support team checking in on your order {{2}}. Has everything arrived and does it fit right?
  Tap a button below so we know. If anything is wrong, we'll take care of it." · QR "Yes, all good" · "Not arrived yet" · "I have an issue"
- **{p}_popup_code_v1** · "Your discount is here" · "Hey, welcome to {BRAND} 👋 Here's your
  code: *{{1}}* Tap the button below and it's already applied at checkout. Not sure where to
  start? Reply and I'll help you choose." · URL "Shop with my code" · QR "Help me choose"
- **{p}_popup_best_v1** · "Where most customers start" · "Hey, quick tip from the {BRAND} team.
  Most customers start with [[bestseller]] because [[one real reason]]. Your code *{{1}}* works
  on it and on everything else." · URL "See it" · QR "A question about it"
- **{p}_popup_last_v1** · "A last note about your code" · "Hey, {SIGNER} from {BRAND} here.
  This is my last note about your welcome gift, I don't want to crowd your phone. Your code
  *{{1}}* is still active for your first order. If something is holding you back, just reply
  and tell me." · URL "Use my code now" · QR "I have a question"
- **{p}_second_order_v1** · "Ready for round two?" · "Hey {{1}}, {SIGNER} from {BRAND} here.
  Thanks again for your first order. Here's {T2}% off your second one with code *{{2}}*. Tap
  below and it's already applied." · URL "Shop with {T2}% off" · QR "Help me choose"
- **{p}_winback_v1** · "We miss you" · "Hey {{1}}, it's been a while since your last order with
  {BRAND}. A lot is new, and to welcome you back here's {T3}% off with code *{{2}}*. Tap below
  and it's already applied." · URL "Come back for {T3}% off" · QR "What's new?"
- **{p}_comeback_v1** · "Good to see you back" · "Hey {{1}}, saw you stopped by {BRAND} again.
  If something caught your eye, here's {T2}% off with code *{{2}}*, already applied when you
  tap below. Looking for something specific? Reply and I'll point you to it." · URL "Back to the store" · QR "Help me find something"
- **{p}_vip_v1** · "You're officially an insider" · "Hey {{1}}, {SIGNER} from {BRAND} here.
  You've ordered with us again and again, and that means a lot to our small team. As a thank-you,
  here's our best code, just for insiders: *{{2}}* Tap below and it's already applied." · URL "Use my insider code" · QR "Thanks!"
