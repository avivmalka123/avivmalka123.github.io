# Ping AI technical rules (learned on a live store)

## Automations
- `createAutomation` with `starter:false` gives an empty flow; build it with ONE `updateAutomation`
  carrying the whole tree. Every step object must carry all required keys: `id, parentId, branch,
  position, kind, scheduleMode, delayMinutes, atHour, body, templateName, templateLanguage,
  templateParams, conditionType, conditionValue, splitPercent, label` — `null` where unused.
  Root step: `parentId:null, branch:null`. Children of a condition: `branch:"yes"|"no"`;
  of a split: `"a"|"b"`. `scheduleMode:"delay"`, `atHour:null`, `position:0`.
- Email step: `kind:"message", channel:"email", emailTemplateId, body:""`.
- WhatsApp template step: `kind:"message", channel:"whatsapp", templateName, templateLanguage,
  templateParams:[...], templateButtons:[...]` (+ `discountCode` when it uses {{discount}} /
  {{link_discount}}). Send `templateButtons` only for templates whose URL button ends in {{1}}.
- Merge: `kind:"merge", conditionValue:<target step id>`; the wait goes on the merge's
  `delayMinutes`. A merge may target a step on another branch, never one above itself.
- Every later edit: `getAutomation` → change → `updateAutomation` with `baseUpdatedAt` =
  its `updatedAt`, keep the ids of unchanged steps. 409 = it changed, read again.
- A trigger can't be changed once the automation ran: make a new one and turn the old one off.
- Adding a split to a running automation puts people already inside it into one arm: note the
  date of the change and compare only from then.
- `enabled:true`, campaign launches and `addResource` are held for the merchant's approval and
  return an approval link. An approval may stop applying if you edit the automation after it:
  finish all edits first, then ask for approval. If a held approval went stale, request again.
- Segment-triggered and site-triggered flows: only customers who agreed to marketing.
- Label every step: "E2 · 24h · 15% {code}" so the owner can read the tree in the dashboard.

## SMS
- Step: `kind:"message", channel:"sms", body`, `shortenLinks:true`. Needs a sender name first
  (`setSmsSenderName`, 2–11 English letters/digits). Allowance in `getSmsSettings`/`getPlan`.
- `createSmsCampaign` can target a segment directly (`audience:"segment", segmentId`), unlike
  email campaigns. `scheduledAt` is ISO; never on Shabbat for an Israeli store.
- Hebrew: 70 characters per part (160 in English). Count before saving.

## Regular WhatsApp (scanned number)
- Text steps (`body`), no templates, no buttons. Low volume only (channels.md §whatsapp).

## WhatsApp templates
- `createWhatsAppTemplate` `examples`: Ping reads it 1-indexed. Pass a dummy first item:
  `examples: ["-", "Mike", "Black hoodie"]` for {{1}}=Mike, {{2}}=Black hoodie.
  The error "missing example for {{n}}" means this was off by one.
- Header: plain text, max 60 chars, NO emoji, no variables.
- Body variables can't be at the very start or end of the body and can't sit next to each other.
- URL button with variable: `url:"https://{DOMAIN}/{{1}}", example:["https://{DOMAIN}/abc123"]`.
  In the automation step, `templateButtons` holds the full link (`{{link}}`, `{{link_discount}}`
  or a literal https URL on the same domain).
- Allowed step variables: {{name}} {{product}} {{items}} {{total}} {{link}} {{link_discount}}
  {{discount}} {{shop}}; orders {{order}} {{order_link}} {{tracking_link}}; pop-up {{coupon}}.
  `{{cart_link}}` is for emails only.
- Segment-triggered flows reject {{link_discount}} / {{discount}}: put the code as a literal
  param and the button as `https://{DOMAIN}/discount/CODE?redirect=%2F`.
- MARKETING vs UTILITY: order confirmation / delivery check = UTILITY, anything with a code or
  a product push = MARKETING. Meta re-categorises wrong ones.
- A WhatsApp step whose template isn't APPROVED yet fails for that customer. Check
  `listWhatsAppTemplates` (or `syncWhatsAppTemplates`) before asking to turn a flow on.
- WhatsApp steps are skipped for customers without a phone: that's why flows branch on
  `has_phone` and give email to the "no" side.

## Email
- `createEmailTemplate` variables: {{name}} {{store}} {{store_link}} {{coupon}} {{cart_link}}
  {{product}} {{product_image}} {{product_price}} {{total}} {{order_number}} {{tracking_link}}.
  Cart/order variables fill only in cart/order automations; in campaigns they're empty.
- A discount link in an email: `https://{DOMAIN}/discount/CODE?redirect=%2F` (applies the code
  and lands on the home page; `%2Fproducts%2F<handle>` for a product).
- Never edit an existing template's text in the dashboard editor by replacing innerText: it
  breaks the variable chips. Create a new template instead.
- Email allowance per month by plan (FREE 10, PRO 5,000, GROWTH 10,000, PREMIUM 20,000,
  GOLD 50,000, UNLIMITED 100,000): automations and campaigns both count. Check
  `getPlan` / `getEmailAudience` before scheduling a campaign to a big segment.
- Test: `sendTestEmail` to the owner's own address (ask for it) for one email per flow.

## Discounts
- `listCoupons` first. `createCoupon` creates the code in Shopify immediately.
- A leaked code (thousands of uses, coupon sites) → suggest a new code; don't silently disable
  a code customers are using, ask the owner.

## Plans
FREE runs at most 3 automations at once. The plan decides whether after-payment automations run.

## Segments
- Rule syntax verified on a live store: `lastOrderDays` can appear twice (a range),
  `emailOpened` with `times`/`timesOp`, `viewedProduct` with `value:""` + `notBought:true`.
- `previewSegment` returns customer names and emails: show the owner only the summary
  (customers, buyers, emailable, whatsappable, spent), never paste the list.
