# 90-day campaign Gantt (Phase 10)

Goal: the owner leaves with a 90-day marketing calendar that is already loaded into Ping:
every holiday and shopping day in the next 90 days, what goes out, to whom, when, with which
offer, plus the evergreen sends between them. Days 1–30 become real campaign drafts in Ping;
days 31–90 stay a plan that is turned into drafts each month ("תכנית לחודש הבא").

## Step 1 · Which calendar
- Customers in Israel → the Israeli table below (Jewish holidays + Israeli commercial days).
- Customers abroad (e.g. a US store) → the international list at the bottom. A store that sells
  to both gets both, but each campaign goes only to the matching audience.
- Dates beyond the table: fetch `https://www.hebcal.com/hebcal?v=1&cfg=json&maj=on&min=on&mod=on&i=on&year=<YYYY>&lg=he`
  (public, no key, never send store data to it).

## Step 2 · Rules for every event
- ⛔ days (Yom Kippur, Holocaust Day, Memorial Day in Israel, Tisha B'Av): no marketing message at all,
  and nothing scheduled for the evening before either. Ping's quiet hours / Shabbat guard
  delay sends; they are not a reason to schedule on Shabbat.
- Window per big event (Rosh Hashana, Hanukkah, Pesach, Black Friday, Christmas abroad):
  T−10 teaser (no code, "something's coming", gift guide) → T−3 VIP early access (`{PFX}VIP` or the
  event code) → T−1/T0 everyone → **shipping cut-off email** (the last day to order and still
  get it before the holiday: holiday − processing − delivery days from `getPolicies`) → last
  chance. Small events (Tu BiShvat, Lag BaOmer): one send, or skip if it doesn't fit the brand.
- Offer: never above the owner's max `{M}`. Big events may use `{M}`; small ones `{T1}` or a
  gift / free shipping. Hanukkah = 8 nights, a different product or bundle each night
  (a "calendar" pop-up can show up to 7 days ahead).
- Fit: only events that make sense for the brand. A baby brand skips Valentine's; a
  motorcycle brand skips Tu B'Av unless the owner wants it. Ask once, show the shortlist.
- Frequency cap: max 2 marketing emails a week per person, max 1 WhatsApp marketing message
  a week. Automations (cart, welcome...) don't count, campaigns do.
- Between events: one evergreen send a week, rotating the hot segments from blueprint §8
  (clicked-not-bought, viewed 7d, second-order window, engaged non-buyers, win-back). Every
  second evergreen send has no discount (bestsellers, a story, a guide).
- Email allowance: sum (segment size × sends) per month against `getPlan`. If it doesn't
  fit, cut the evergreen sends to the biggest segments first, never the event's main send.

## Step 3 · Build it in Ping (days 1–30)
For each send in the first 30 days:
1. `createEmailTemplate` in the brand design (emails.md), named "<event> · <step>".
2. `createEmailCampaign` draft with `scheduledAt` "YYYY-MM-DD HH:mm" (Israel time; usual slots
   Sun–Thu 10:00 or 20:00, Friday until 11:00, Saturday night after Shabbat 21:00).
   Audience: the tool takes a list or the pop-up leads. For a segment, create the draft and
   tell the owner the 3 clicks to switch the audience to the segment in the campaign screen.
3. `launchEmailCampaign` → it's held for the owner's approval: collect the links.
4. Big events with WhatsApp: one MARKETING template per event ("{p}_<event>_v1", code as {{1}}),
   then `createBroadcast` as a draft to marketing-subscribed numbers of the right segment. Starting
   it is the owner's.
5. Optional: a countdown pop-up for the biggest event (`createBanner` with `countdownTo` the event
   date, the event code in `success.coupon`, draft).

## Step 4 · The Gantt in the report
Add a "90 יום קדימה" section to the report page:
- X axis = weeks (Sunday starts), today marked, ⛔ days shaded red, Shabbat columns light grey.
- One row per event: a bar for its window, a dot for each send (teaser / VIP / main / cut-off /
  last chance), colour by channel (email / WhatsApp / pop-up), the code on the bar.
- A row "שבועי" with the evergreen sends and their segment.
- Under the chart: a table of every send in date order: date · time · channel · audience ·
  subject line (one line) · code · status in Ping (draft / waiting approval / plan only).
- Monthly rebuild: tell the owner to write "תכנית לחודש הבא" around day 25.

## Israeli calendar (Nov 2026 – Dec 2028, from Hebcal, Israel)
| מתי | מה | מה עושים בחנות |
|---|---|---|
| 11.11.2026 | 11.11 · יום הרווקים | מבצע של יום אחד. חימום לבלאק פריידיי |
| 27.11.2026 | בלאק פריידיי | השבוע הכי גדול בשנה. קודם גישה מוקדמת ל־VIP, ואחר כך לכולם |
| 30.11.2026 | סייבר מאנדיי | ההזדמנות האחרונה של סוף השבוע |
| 04.12–12.12.2026 | חנוכה | 8 ימים, מבצע לכל נר. מתנות |
| 25.12.2026 | כריסמס | רק לחנויות שמוכרות לחו״ל. סגירת הזמנות לפי זמני המשלוח |
| 31.12.2026 | סוף שנה | סיכום השנה: הנמכרים של השנה |
| 23.01.2027 | ט״ו בשבט | יום קטן: טבע ובריאות |
| 07.02.2027 | יום המשפחה | מתנות להורים |
| 14.02.2027 | ולנטיין | מתנות לזוגות |
| 22.03–24.03.2027 | פורים | תחפושות, משלוחי מנות, צבע והומור |
| 21.04–28.04.2027 | פסח | ניקיון, בית, מטבח ובגדים חדשים. סגירת הזמנות לפני החג |
| 04.05.2027 | יום השואה | ⛔ אין שום הודעה שיווקית |
| 09.05.2027 | יום האם בארה״ב | רק לחנויות שמוכרות לארה״ב |
| 11.05–12.05.2027 | יום הזיכרון ויום העצמאות | ⛔ ביום הזיכרון אין שיווק. ביום העצמאות: על האש, כחול לבן, מבצעים |
| 25.05.2027 | ל״ג בעומר | יום קטן: מדורות ובחוץ |
| 10.06–11.06.2027 | שבועות | לבן, מוצרי חלב וחקלאות |
| 20.06.2027 | יום האב בארה״ב | רק לחנויות שמוכרות לארה״ב |
| 11.08–12.08.2027 | תשעה באב | ⛔ אין שום הודעה שיווקית |
| 18.08.2027 | ט״ו באב | יום האהבה הישראלי: זוגות ומתנות |
| 25.08–01.09.2027 | חזרה ללימודים | ילדים: תיקים, ציוד ובגדים |
| 01.10–03.10.2027 | ראש השנה | מתנות וסטים לחג. קמפיין 10–14 יום לפני. סגירת הזמנות לפי זמני המשלוח |
| 10.10–11.10.2027 | יום כיפור | ⛔ אין שום הודעה שיווקית |
| 15.10–23.10.2027 | סוכות ושמחת תורה | חופש: משפחות, טיולים, ילדים |
| 11.11.2027 | 11.11 · יום הרווקים | מבצע של יום אחד. חימום לבלאק פריידיי |
| 26.11.2027 | בלאק פריידיי | השבוע הכי גדול בשנה. קודם גישה מוקדמת ל־VIP, ואחר כך לכולם |
| 29.11.2027 | סייבר מאנדיי | ההזדמנות האחרונה של סוף השבוע |
| 24.12–01.01.2028 | חנוכה | 8 ימים, מבצע לכל נר. מתנות |
| 25.12.2027 | כריסמס | רק לחנויות שמוכרות לחו״ל. סגירת הזמנות לפי זמני המשלוח |
| 31.12.2027 | סוף שנה | סיכום השנה: הנמכרים של השנה |
| 12.02.2028 | ט״ו בשבט | יום קטן: טבע ובריאות |
| 14.02.2028 | ולנטיין | מתנות לזוגות |
| 27.02.2028 | יום המשפחה | מתנות להורים |
| 11.03–13.03.2028 | פורים | תחפושות, משלוחי מנות, צבע והומור |
| 10.04–17.04.2028 | פסח | ניקיון, בית, מטבח ובגדים חדשים. סגירת הזמנות לפני החג |
| 24.04.2028 | יום השואה | ⛔ אין שום הודעה שיווקית |
| 01.05–02.05.2028 | יום הזיכרון ויום העצמאות | ⛔ ביום הזיכרון אין שיווק. ביום העצמאות: על האש, כחול לבן, מבצעים |
| 14.05.2028 | יום האם בארה״ב | רק לחנויות שמוכרות לארה״ב |
| 14.05.2028 | ל״ג בעומר | יום קטן: מדורות ובחוץ |
| 30.05–31.05.2028 | שבועות | לבן, מוצרי חלב וחקלאות |
| 18.06.2028 | יום האב בארה״ב | רק לחנויות שמוכרות לארה״ב |
| 31.07–01.08.2028 | תשעה באב | ⛔ אין שום הודעה שיווקית |
| 07.08.2028 | ט״ו באב | יום האהבה הישראלי: זוגות ומתנות |
| 25.08–01.09.2028 | חזרה ללימודים | ילדים: תיקים, ציוד ובגדים |
| 20.09–22.09.2028 | ראש השנה | מתנות וסטים לחג. קמפיין 10–14 יום לפני. סגירת הזמנות לפי זמני המשלוח |
| 29.09–30.09.2028 | יום כיפור | ⛔ אין שום הודעה שיווקית |
| 04.10–12.10.2028 | סוכות ושמחת תורה | חופש: משפחות, טיולים, ילדים |
| 11.11.2028 | 11.11 · יום הרווקים | מבצע של יום אחד. חימום לבלאק פריידיי |
| 24.11.2028 | בלאק פריידיי | השבוע הכי גדול בשנה. קודם גישה מוקדמת ל־VIP, ואחר כך לכולם |
| 27.11.2028 | סייבר מאנדיי | ההזדמנות האחרונה של סוף השבוע |
| 12.12–20.12.2028 | חנוכה | 8 ימים, מבצע לכל נר. מתנות |
| 25.12.2028 | כריסמס | רק לחנויות שמוכרות לחו״ל. סגירת הזמנות לפי זמני המשלוח |
| 31.12.2028 | סוף שנה | סיכום השנה: הנמכרים של השנה |
Ranges include the eve. The family day (יום המשפחה) is Israel's Mother's/Father's Day.

## International calendar (stores selling abroad)
Rules, compute the date for the year: Valentine's 14.2 · Mother's Day US 2nd Sunday of May ·
Memorial Day US last Monday of May · Father's Day US 3rd Sunday of June · Independence Day 4.7 ·
Back to school mid-Aug · Labor Day 1st Monday of Sept · Halloween 31.10 · Singles' Day 11.11 ·
Thanksgiving 4th Thursday of Nov → Black Friday the next day → Cyber Monday 3 days later ·
Christmas 25.12 (shipping cut-off usually ~18–20.12) · New Year 31.12. UK Mother's Day differs
(4th Sunday of Lent) — ask if the store sells to the UK.
