# The blueprint

Placeholders: `{BRAND}` brand name · `{SIGNER}` real first name of the signer · `{DOMAIN}` the
store's public domain (not the myshopify one, take it from `getConnections`/`getOverview`) ·
`{PFX}` 2–4 capital letters from the brand (American Legend Rider → ALR) · `{p}` the same in
lowercase for template names · `{M}` max discount · `{T1} {T2} {T3}` the ladder.

## §1 Discount ladder and codes
- `T3 = M` · `T2 = round down to 5 of (M × 0.75)` · `T1 = round down to 5 of (M × 0.5)`, at least 5.
  If M < 10: one code of M for everything, and offer free shipping as the softer step.
  If M = 0: no codes at all. Every "offer" step becomes free shipping (if they agree) or a
  value step (help choosing, reviews, guarantee). The flows still work.
- Codes (single, `oncePerCustomer: true`, `kind: percent`):
  `{PFX}{T1}` welcome (pop-up) · `{PFX}BACK{T2}` second chance · `{PFX}LAST{T3}` last chance ·
  `{PFX}VIP{T3}` loyal customers only.
- Never send the highest code first. Order in every flow: help → reminder → T2 → T3.
- A discount step always says why the customer gets it (welcome, came back, loyal) and when it
  ends only if a real end date exists.

## §2 Timing rules
Quiet hours and the Shabbat guard are Ping's and delay, never cancel. Delays below are
`delayMinutes` after the previous step on the same path.
Shopify sends its own order confirmation email: never duplicate it by email.

## §3 Segments (preview first, create when count > 0)
| Name (owner's language) | rules |
|---|---|
| 🔥 לחצו במייל ב־14 יום ולא קנו 30 יום | `[{field:"emailClicked",op:"within",days:14},{field:"purchased",op:"notWithin",days:30}]` |
| 🔥 צפו במוצר ב־7 ימים ולא קנו | `[{field:"viewedProduct",op:"within",days:7,value:"",notBought:true}]` |
| 🔥 לקוחות שחזרו לאתר ב־14 יום, בלי הזמנה 45 יום | `[{field:"siteVisit",op:"within",days:14},{field:"orders",op:"gte",value:1},{field:"lastOrderDays",op:"gte",value:45}]` |
| הזמנה שנייה · קנו פעם אחת לפני 30–120 יום | `[{field:"orders",op:"eq",value:1},{field:"lastOrderDays",op:"gte",value:30},{field:"lastOrderDays",op:"lte",value:120}]` |
| טריגר · יום 45 אחרי קנייה ראשונה | `[{field:"orders",op:"eq",value:1},{field:"lastOrderDays",op:"gte",value:45},{field:"lastOrderDays",op:"lte",value:60}]` |
| מתעניינים · פתחו 3+ מיילים ב־30 יום ולא קנו אף פעם | `[{field:"emailOpened",op:"within",days:30,times:3,timesOp:"gte"},{field:"orders",op:"eq",value:0}]` |
| החזרת לקוחות · 90–365 יום בלי הזמנה | `[{field:"orders",op:"gte",value:1},{field:"lastOrderDays",op:"gte",value:90},{field:"lastOrderDays",op:"lte",value:365}]` |
| VIP · 3+ הזמנות, קנו ב־60 יום | `[{field:"orders",op:"gte",value:3},{field:"lastOrderDays",op:"lte",value:60}]` |
| נאמנים · 4+ הזמנות בשנה האחרונה | `[{field:"orders",op:"gte",value:4},{field:"lastOrderDays",op:"lte",value:365}]` |
Write names in the owner's language. A segment that already exists with the same meaning is reused.

## §4 The 8 automations
Each spec is the step tree for `updateAutomation`. `E:` = email step (`channel:"email"`,
`emailTemplateId`), `WA:` = WhatsApp template step. Ids are short new ids (`c0`, `e1`...).
"WA only" parts are dropped when there is no official WhatsApp line: the `has_phone`
condition is removed and its "no" branch becomes the main path.

### 1 · Checkout abandon — `abandoned_checkout` · name "הגיע לקופה · קופה נטושה"
stopWhen `{purchased:true, replied:true}`
```
c0  condition has_phone            delay 20        (root)
├─ yes → s1 split 50% "A/B: link vs question"
│        ├─ a → wa1a WA {p}_checkout_saved_v1     params [{{name}},{{product}}]  buttons [{{link}}]
│        │      → m1 merge → e1   delay 40
│        └─ b → wa1b WA {p}_checkout_question_v1  params [{{name}},{{product}}]
│               → m2 merge → e1   delay 40
└─ no  → e1 E "1h · reminder, no discount"         delay 40
         → c2 condition has_phone  delay 0
           ├─ yes → wa2 WA {p}_checkout_offer_v1 delay 1380 params [{{name}},{{product}},{{discount}}]
           │        buttons [{{link_discount}}] discountCode {PFX}BACK{T2}
           │        → m3 merge → e3  delay 2880
           └─ no  → e2 E "24h · T2 code"           delay 1380
                    → e3 E "3 days · T3 last chance" delay 2880
```
Email-only store: root = split 50% → a: e1a "product-first" (60) / b: e1b "personal note from
{SIGNER}, plain look" (60) → merge to e2 (1380) → e3 (2880). The test = which first email
brings more checkouts back.

### 2 · Pop-up leads — `banner_lead`, triggerConfig `{bannerId:null}` (every pop-up) · "ליד מפופאפ · ברוכים הבאים"
stopWhen `{purchased:true, replied:false}`. The code is the pop-up's own: `{{coupon}}`.
```
p0  condition has_phone   delay 3   (root)
├─ yes → wp1 WA {p}_popup_code_v1  delay 0    params [{{coupon}}]
│          buttons ["https://{DOMAIN}/discount/{{coupon}}?redirect=%2F"]
│        → wp2 WA {p}_popup_best_v1 delay 2880 params [{{coupon}}]
│          buttons ["https://{DOMAIN}/discount/{{coupon}}?redirect=%2Fproducts%2F<bestseller-handle>"]
│        → wp3 WA {p}_popup_last_v1 delay 7200 params [{{coupon}}] buttons [same as wp1]
└─ no  → s1 split 50% "A/B: code first vs story first"
         ├─ a → w1a E "welcome · the code up top"           delay 0
         └─ b → w1b E "welcome · who we are, then the code" delay 0 → m1 merge → w2 delay 2880
         w1a → w2 E "day 2 · where most customers start (bestseller)" delay 2880
             → w3 E "day 5 · questions people ask before buying"    delay 4320
             → w4 E "day 9 · what customers say" (only with real reviews; else skip) delay 5760
             → w5 E "day 14 · a last note about your code"           delay 7200
```
If the store already has a pop-up with its own after-lead automation, turn that one off after
this one is approved so leads don't get both.

### 3 · Product view — `viewed_product`, triggerConfig `{waitMinutes:60, cooldownDays:7}` · "צפה במוצר · לא קנה"
stopWhen `{purchased:true, replied:true, abandoned:true}` (a checkout moves them to flow 1). No discount.
```
v1  E "1h · still thinking? the product + 3 reasons"   delay 0 (root)
→ c1 condition has_phone delay 0
  ├─ yes → wv WA {p}_browse_v1 delay 1440 params [{{name}},{{product}}] buttons [{{link}}]
  │        → m1 merge → v3 delay 2880
  └─ no  → v2 E "day 1 · answers to the usual questions" delay 1440
           → v3 E "day 3 · what others bought instead"   delay 2880
```
Send one `sendTestEmail` of v1: if {{product}} / {{product_image}} come out empty in this
flow, switch v1 to a bestsellers block with a general headline.

### 4 · After purchase — `order_paid` · "שילם · תודה ובדיקת משלוח"
stopWhen `{purchased:false, replied:false}`. Service, not selling. No discount.
```
o1 E "thank you from {SIGNER} + what happens now" delay 5 (root)
→ c1 condition has_phone delay 0
  ├─ yes → wo1 WA {p}_order_confirmed_v1 (UTILITY) delay 0     params [{{name}},{{order}}]
  │        → wo2 WA {p}_order_arrived_v1 (UTILITY) delay 14400 params [{{name}},{{order}}]
  └─ no  → o2 E "day 10 · did it arrive? just reply"  delay 14400
```
On FREE/PRO the plan may not run after-payment automations: say so, keep it built and off.

### 5 · Second order — `segment_entered`, segment "טריגר · יום 45", cooldownDays 90 · "קנו פעם אחת · הזמנה שנייה"
stopWhen `{purchased:true, replied:true}`. Segment flows can't use `{{link_discount}}`: literal code and URL.
```
s1 E "what goes with what you bought" (cross-sell, no code) delay 0 (root)
→ c1 condition has_phone delay 0
  ├─ yes → ws WA {p}_second_order_v1 delay 2880 params [{{name}},"{PFX}BACK{T2}"]
  │        buttons ["https://{DOMAIN}/discount/{PFX}BACK{T2}?redirect=%2F"]
  │        → m1 merge → s2 delay 4320
  └─ no  → s2 E "T2 for your second order, ends soon" delay 2880
```
(on the yes path s2 comes 3 days after the WhatsApp; on the no path s2 is the code email itself)

### 6 · Win-back — `segment_entered`, segment "90–365 יום בלי הזמנה", cooldownDays 180 · "90 יום בלי הזמנה · החזרה"
stopWhen `{purchased:true, replied:true}`
```
wb1 E "it's been a while · what's new" delay 0 (root)
→ wb2 E "T3 to welcome you back"       delay 4320
→ c1 condition has_phone delay 0
  ├─ yes → ww WA {p}_winback_v1 delay 2880 params [{{name}},"{PFX}LAST{T3}"]
  │        buttons ["https://{DOMAIN}/discount/{PFX}LAST{T3}?redirect=%2F"]
  └─ no  → wb3 E "last note about your code" delay 4320
```

### 7 · Came back to the site — `returned_to_site`, triggerConfig `{awayDays:30, cooldownDays:30}` · "חזר לאתר אחרי 30 יום"
stopWhen `{purchased:true, replied:true, abandoned:true}`
```
c0 condition has_phone delay 60 (root)
├─ yes → wr WA {p}_comeback_v1 delay 0 params [{{name}},"{PFX}BACK{T2}"]
│        buttons ["https://{DOMAIN}/discount/{PFX}BACK{T2}?redirect=%2F"]
│        → m1 merge → r2 delay 2880
└─ no  → r1 E "good to see you back + T2" delay 0
         → r2 E "bestsellers this month"   delay 2880
```

### 8 · VIP — `segment_entered`, segment "VIP", cooldownDays 120 · "VIP · תודה ללקוחות הכי טובים"
stopWhen `{purchased:true, replied:true}`
```
vip1 E "you're one of our best customers · early access" delay 0 (root)
→ c1 condition has_phone delay 0
  ├─ yes → wvip WA {p}_vip_v1 delay 1440 params [{{name}},"{PFX}VIP{T3}"]
  │        buttons ["https://{DOMAIN}/discount/{PFX}VIP{T3}?redirect=%2F"]
  │        → m1 merge → vip3 delay 4320
  └─ no  → vip2 E "your insider code"         delay 1440
           → vip3 E "last days for your insider code" delay 4320
```
Optional 9 · Birthday: only if `getAutomationTriggerOptions.birthdays > 0`: `birthday`,
daysBefore 3, one email (+ WA) with T2.

## §5 WhatsApp templates (official line only)
All MARKETING unless marked. URL buttons: `url: "https://{DOMAIN}/{{1}}"`,
`example: ["https://{DOMAIN}/abc123"]`. Footer: "{BRAND} · Reply STOP to opt out" (Hebrew:
"{BRAND} · להסרה השיבו הסר"). Header: plain text, no emoji. Copy: copy-he.md / copy-en.md §WA.
| name | body vars | buttons |
|---|---|---|
| {p}_checkout_saved_v1 | 1 name · 2 product | URL "finish my order" + QR "I have a question" |
| {p}_checkout_question_v1 | 1 name · 2 product | 4 QR: price / shipping time / size or fit / something else |
| {p}_checkout_offer_v1 | 1 name · 2 product · 3 code | URL "claim my X% off" + QR |
| {p}_browse_v1 | 1 name · 2 product | URL "take another look" + QR |
| {p}_order_confirmed_v1 (UTILITY) | 1 name · 2 order | QR "question about my order" |
| {p}_order_arrived_v1 (UTILITY) | 1 name · 2 order | 3 QR: all good / not arrived / issue |
| {p}_popup_code_v1 | 1 code | URL "shop with my code" + QR "help me choose" |
| {p}_popup_best_v1 | 1 code | URL "see <bestseller>" + QR |
| {p}_popup_last_v1 | 1 code | URL "use my code" + QR "I have a question" |
| {p}_second_order_v1 | 1 name · 2 code | URL + QR "help me choose" |
| {p}_winback_v1 | 1 name · 2 code | URL + QR "what's new?" |
| {p}_comeback_v1 | 1 name · 2 code | URL + QR "help me find" |
| {p}_vip_v1 | 1 name · 2 code | URL + QR "thanks!" |

## §6 The pop-up (only if the store has no lead pop-up)
`listBannerTemplates` → pick a lead template → `createBanner` status "draft":
fields email (required) + phone (optional) or a second "leave your phone too" screen with
`phoneCoupon`; `success.coupon = {PFX}{T1}`, `success.show: true`; brand colours and fonts
from `getStoreBrand`; triggers `onLoadDelay: 8` + `exitIntent: true`; frequency show "day",
hideAfterSubmit true; headline in the customer language, e.g. "{T1}% על ההזמנה הראשונה".
It can go live only after flow 2 is on: tell the owner it's the last approval.

## §7 Bot sales playbook (`addResource`, title "WhatsApp playbook · checkout question replies")
Fill from real policies. ≤ 3,500 chars. Structure:
```
When a customer taps a reply on the "what held you back?" message:
• "The price" → acknowledge, one line of value (what's included: shipping/returns from
  policy), then: "Here's {T2}% off just for you: {PFX}BACK{T2} — this link applies it:
  https://{DOMAIN}/discount/{PFX}BACK{T2}?redirect=%2Fcheckout". Never go above {T2} in chat.
• "Shipping time" → the real processing + delivery times from the policy; if they're in a rush,
  the fastest real option. Then offer the code once.
• "Size or fit" → ask which product and their usual size; point to the size chart page;
  remind them of the return/exchange policy. Code only if they still hesitate.
• "Something else" → one open question: "Sure, what's on your mind?"
Rules: one question per message, short, signed {SIGNER}; never invent stock, deadlines or
reviews; complaints, refunds and order problems → hand to a human.
```

## §8 Hot-segment campaigns (after the flows, on request)
One email per hot segment from §3, built like §emails, sent as campaign drafts:
clicked-not-bought → "still on your mind?" + T2 · viewed 7d → "the products you looked at" ·
returned buyers → "new since your last order" · second-order window → cross-sell + T2 ·
engaged non-buyers → "first order" T1 · loyal → early access, no code · imported list →
"we moved: here's what's new" (once). Check the email allowance (`getPlan`) first; if a
campaign tool can't target a segment, create the template and tell the owner the 3 clicks to
pick the segment in the campaign screen.
