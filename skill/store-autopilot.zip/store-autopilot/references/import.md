# Bringing the contacts in (Phase 2)

The list is the treasure: people who already raised their hand. Nothing gets lost in the move.

Import page: https://pingai.org/shopify/import (the owner does the upload/key there; you watch
progress with `listPlatformImports`).

## Shopify (always)
- Customers, orders and abandoned checkouts come in with the app.
- Run `syncOrderHistory` once so "ordered once / 90 days / VIP" rules count the full history.
- Shopify customer tags become usable in segments (`{ field: "tag" }`).

## Klaviyo (direct connection, best option)
1. In Klaviyo: Settings → API keys → "Create Private API Key", name it "Ping", read-only access
   to Profiles, Lists, Segments (full read is fine).
2. Paste the key on the import page → Klaviyo.
Ping brings profiles, lists and the people who unsubscribed/bounced/marked spam (they are kept
out of marketing automatically).

## Flashy, Omnisend, Mailchimp, ActiveTrail, Smoove, any other tool (CSV)
1. In the old tool, export ALL contacts to CSV, including unsubscribed ones. If the tool
   exports unsubscribed contacts as a separate file, export that too.
   Columns to keep: email, phone, first name, last name, subscription status, tags/lists.
2. Upload each file on the import page and map the columns (email / phone / name / status).
3. Upload the unsubscribed file too: Ping keeps those people out of every marketing message.
If the owner can't find the export button, search the tool's help center for "export contacts"
for them and give the exact clicks. Never guess menu names.

## WhatsApp contacts from a phone
Only people who agreed to receive marketing. If the owner has a group or a broadcast list,
recommend the pop-up + WhatsApp flow instead of uploading phone numbers without consent.

## After the import
- Report: profiles read, kept from marketing (suppressed), lists made.
- `getAutomationTriggerOptions` now shows presets like "Came from Flashy import" — use them
  to make a "welcome to our new club" campaign later (blueprint.md §8).
- Old tool still sending? Tell the owner to turn off the flows there only AFTER the Ping flows
  are approved, so no customer gets two abandoned-cart emails. Cancel the old subscription
  only after a week of Ping results.
