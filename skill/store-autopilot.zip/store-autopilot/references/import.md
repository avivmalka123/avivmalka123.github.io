# The migration (Phase 2): every contact moves, nothing breaks, the old tool keeps running

The list is the treasure: people who already raised their hand. The owner should feel the move
is light: you lead every click, and nothing is cancelled until Ping shows results.

Import page: https://pingai.org/shopify/import (the owner uploads the file or pastes the key
there; you watch progress with `listPlatformImports`).

## The promise, kept in practice
"Parallel" means: the old tool stays, with its list and its history, as a safety net. It does
NOT mean two tools sending the same message. Per trigger, only one tool sends:
| When | What the owner does in the old tool |
|---|---|
| Now (Phase 2) | Nothing. Export only. Everything keeps running as usual |
| The day a Ping flow is approved | Turns off **only the matching flow** in the old tool (Ping abandoned cart on → old abandoned cart off; Ping welcome on → old welcome off). Give the exact flow name and the toggle |
| Newsletters / campaigns | From the first Ping campaign on, campaigns go out from Ping only |
| After 7 days of Ping results (the "דוח אוטופיילוט") | The owner decides: cancel the old subscription or keep it. Recommend exporting one last backup file first |
Say it to the owner in one line each time a Ping flow is approved: "אישרת את העגלה הנטושה
בפינג. עכשיו, כדי שלקוח לא יקבל שתי תזכורות, כבה ב־{TOOL} את {flow}. את כל השאר שם לא נוגעים."

## Shopify (always, automatic)
- Customers, orders and abandoned checkouts come in with the app. Nothing to export.
- Run `syncOrderHistory` once so "ordered once / 90 days / VIP" rules count the full history.
- Shopify customer tags are usable in segments (`{ field: "tag" }`).
- Shopify's own "accepts marketing" status comes along: people who didn't agree aren't marketed to.

## Klaviyo (a key, no files)
1. In Klaviyo: Settings → API keys → **Create Private API Key** → name it "Ping" → access level
   **Read-Only** → Create. Only an Owner, Admin or Manager can create keys.
2. Copy the key right away: Klaviyo shows it once (it starts with `pk_`).
3. On the import page → Klaviyo → paste → start.
Ping brings profiles, lists, and the people who unsubscribed, bounced or marked spam (they stay
out of marketing automatically).

## Flashy (a file sent by email)
1. In Flashy: **Contacts** (top menu) → on the left choose the list or segment (start with all
   contacts) → **Export Contacts** → type the email to receive it → Export.
2. The file arrives by email after a few minutes (big lists take longer).
3. Repeat for unsubscribed / bounced contacts if Flashy lists them separately, so they stay
   protected in Ping.
4. Upload each file on the import page and map: email · phone · first name · last name · status.

## ActiveTrail, Smoove, Rav Messer, Inforu, Mailchimp, Omnisend, any other tool (CSV)
1. Export ALL contacts to CSV, including unsubscribed ones. Look for a status filter in the
   export ("all statuses" / "unsubscribed") or a status column. If the tool exports unsubscribed
   people as a separate file, export that file too.
2. Columns to keep: email, phone, first name, last name, subscription status, tags/lists.
3. Upload each file on the import page and map the columns.
If you don't know the exact clicks for the tool, search its help center for "export contacts"
right then and give the steps from there. Never guess menu names.

## No tool at all
"אז מתחילים נקי. אנשי הקשר מגיעים משופיפיי, והפופאפ מתחיל לאסוף חדשים מהיום."

## WhatsApp numbers from a phone
Only people who agreed to receive marketing. For a group or a broadcast list, recommend the
pop-up + WhatsApp flow instead of uploading numbers without consent.

## Check the move (show the owner, 3 lines)
- "קראתי N אנשי קשר מ־{TOOL}. בפינג נכנסו M, ו־S מוגנים (הסירו את עצמם, לא יקבלו כלום)."
- If N and M differ by more than a few percent: find out why (a missing file, a status filter)
  before building.
- Spot-check: show 2 contacts the owner knows (by first name only) with their consent status.
Then: "הכול עבר. ב־{TOOL} עדיין לא נגענו בכלום."
