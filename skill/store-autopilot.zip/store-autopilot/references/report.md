# Handover report + week-1 check (Phase 12)

## The report page
One page, in the owner's language (Hebrew RTL for Israeli owners), the store's brand colours.
Title: "הבקאנד של {BRAND} · מה הותקן היום". Sections:
1. **Top line**: X automations, Y emails, Z WhatsApp templates, N segments, codes, A/B tests —
   big numbers in a row.
2. **What still needs your click**: every approval link, grouped, each with one line of what it
   turns on. This is the most important section — put it right under the top line.
3. **The automations**: one card per flow — trigger in plain words ("מישהו הגיע לקופה ולא
   שילם"), a horizontal timeline of steps (icon email/WhatsApp, delay, what it says, code),
   the A/B split drawn as a fork with what each arm tests, and an "open in Ping" link
   (`https://pingai.org/shopify/automations/<id>`).
4. **Segments**: name · how many people today · what they'll get.
5. **Codes**: code · % · where it's used.
6. **What we'll know in 7 days**: the questions each A/B test answers.
Never paste the full email/WhatsApp copy on the page — a one-line summary per step is enough;
the content lives in Ping.
Claude.ai: build it as an artifact. Claude Code: write `autopilot-report-<brand>.html` in the
working folder and open it.

## Week-1 check ("דוח אוטופיילוט")
Read only. For each automation built by this skill (`listAutomations`, names from the report):
- `getAutomation` → `stats` (enrolled, sent, recovered, boughtAfter orders/value) and
  `stepStats` (sent/skipped/failed per step) and `splitResults` (reached/sent/recovered per arm).
- `getAutomationAnalytics` where available for revenue in the window.
- WhatsApp question arm: `listConversations` / `getConversationMessages` for customers who
  replied → count replies per button, quote 2–3 short anonymised exchanges.
- `getCartRecoveryOverview` for the cart number.
Report in the owner's language:
1. Money first: orders and revenue after the automations this week.
2. Per A/B test: arm A vs B (reached, conversion), the leader, and honestly whether the sample
   is big enough (under ~100 per arm = "direction only, keep it running").
3. What broke: failed steps (e.g. WhatsApp template not approved, missing email), skipped
   steps explained.
4. One recommended change, with the reason. Make it only after the owner says yes.
