# The free backend check (before Phase 0): win the skeptic with their own numbers

The owner who doubts doesn't need a pitch. They need to see, in their own numbers, what their
current setup leaves on the table, and that trying costs nothing. Rules:
- Facts only. Never say another tool is bad, never invent its price or features. The owner's
  own answers make the case ("does your tool do X?" → "no").
- Every estimate shows its formula and is labelled "הערכה". The real number comes after the
  free connection.
- It takes 3–4 minutes and ends with one clear step.

## Step 1 · Five quick questions (one form, defaults allowed)
1. כתובת החנות?
2. באיזו מערכת דיוור / SMS אתה משתמש היום? [אף אחת]
3. כמה אתה משלם עליה בחודש? [לא יודע]
4. כמה הזמנות בחודש בערך, ומה הסל הממוצע? [לא יודע]
5. כמה אנשי קשר יש לך ברשימה בערך?

## Step 2 · Look at the store from the outside (if web fetch is available)
Fetch the home page and one product page. Note only what you can actually see:
pop-up that asks for email/phone · a WhatsApp button · a site chat · shipping time stated on the
product page · returns policy page · accessibility statement link (Israel) · reviews shown.
If you can't fetch, ask the owner the same items as yes/no.

## Step 3 · Ten yes/no checks about the backend (the owner answers; you already know some)
1. מי שנוטש קופה מקבל תזכורת תוך שעה?
2. התזכורת יוצאת גם בוואטסאפ, לא רק במייל?
3. יש פופאפ שאוסף גם טלפון, עם קוד שמגיע מיד?
4. מי שצפה במוצר ולא קנה מקבל הודעה?
5. מי שקנה פעם אחת מקבל הצעה להזמנה שנייה?
6. לקוח שנעלם 90 יום מקבל "התגעגענו"?
7. יש תכנית מבצעים מסודרת לחגים של השנה הקרובה?
8. מישהו עונה ללקוחות בוואטסאפ גם בלילה ובשבת?
9. יש באתר הצהרת נגישות? (חנויות בישראל)
10. אתה רואה כל בוקר כמה כסף האוטומציות הכניסו אתמול?
Score = 10 points per "yes". Show it big: "ציון הבקאנד שלך: 30/100".

## Step 4 · The money on the table (estimate, formula shown)
If the owner gave orders/month and average order:
- Carts started ≈ orders ÷ (1 − 70%). The 70% is the average online **cart** abandonment rate
  documented by Baymard Institute; say "נטישת עגלה ממוצעת" (not "נטישת קופה").
- Abandoned carts a month ≈ started − orders. Value ≈ abandoned × average order.
- Show: "בחודש נשארות אצלך בערך N עגלות נטושות, בשווי כ־₪V. כל 5% שחוזרות = כ־₪(V×5%) בחודש."
  Say it's an example, not a promise.
- After Ping is connected, the real number is abandoned **checkouts** from
  `getCartRecoveryOverview` (people who reached checkout): it's smaller and more precise. Say which
  one you're showing.
If they don't know: skip the estimate and go straight to Step 6 ("נמדוד את זה ביחד").

## Step 5 · The savings comparison (references/pricing.md)
What they pay today (their invoice) vs. Ping for the same volume (plan + extra contacts), in
three lines, in shekels. Then what's included that they answered "no" to. If they qualify, the
November SMS bonus is one calm sentence inside this step (pricing.md §4), never a banner.
Risk off: "הכול נבנה כבוי. לא מבטלים כלום אצל הספק הנוכחי עד שרואים שבוע של תוצאות. הנתונים
נשארים שלך."

## Step 6 · One step: the real number
"רוצה לראות את המספר האמיתי מהחנות שלך? מתקינים את פינג בחינם (2 דקות) ואני מושך את 30
הימים האחרונים." → connect.md. Right after Phase 0 passes: `syncCarts`, then
`getCartRecoveryOverview` → "ב־30 הימים האחרונים ננטשו אצלך N קופות בשווי ₪V, וחזרו M."
That number is the turning point: then continue to Phase 1.

## Make it a page
Show the result as a small page in the store's colours (Claude.ai: artifact; Claude Code: HTML
file opened on the computer): the score ring, the ten checks with ✓/✗, the money estimate with its
formula, the cost line, and one button-like line "להתקנה חינם של פינג". Same design language as
assets/gantt.html.
