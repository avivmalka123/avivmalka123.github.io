# Email design system (Phase 5)

Goal: every email looks like the brand made it by hand. One look across all flows.

## Theme from the brand
`getStoreBrand` → primary colour, background, text colour, fonts. Map to `theme`:
- `primaryColor` = the brand's button/accent colour (must contrast with white text; darken if not)
- `background` = a soft neutral close to the site background (#F6F4F0 if unknown)
- `cardBackground` = #FFFFFF (or the site's dark colour for a dark brand)
- `textColor` = #1A1A1A on light, #F4F1EA on dark · `mutedColor` = 60% of text
- `font`: "rubik" for Hebrew, "system" for a modern Latin brand, "serif" for a classic/luxury brand
- `radius`: 0 for bold/streetwear/auto, 8 for most, 16 for soft beauty/baby brands
- `lang`: the customer language ("he" right-to-left)
Logo: the `header` block with the store logo url if `getStoreBrand` or the site gives one,
otherwise the brand name as text.

## Real content only
- Products: `searchProducts` / `getProductInsights` → 3–6 real bestsellers with image, title,
  price and URL. Use their real images in `hero`, `product` and `columns` blocks.
- Policies: `getPolicies` → shipping time, returns window, guarantee. Only what exists.
- Reviews: only if the owner gives real ones or the store shows them. Otherwise skip that email.

## Block recipes (blocks array for createEmailTemplate)
Keep every email short: one idea, one button. 5–9 blocks.

**Reminder (cart / product)**
header → heading (lg, the hook) → text (2 lines) → product ({{product_image}}, {{product}},
{{product_price}}, button → {{cart_link}}) → list (check marker, 3 real trust lines: shipping,
returns, support) → button (primary, full) → footer.

**Code email**
header → hero (real lifestyle/product image, title = "{T}% off" in big type, button) → text
(why you get it, 2 lines) → coupon (code, label "your code") → button (link
https://{DOMAIN}/discount/CODE?redirect=%2F) → columns (3 bestsellers, imageFit square) → footer.

**Story / welcome-B**
header → image (edge) → heading (md, "Hi, I'm {SIGNER}") → text (3 short paragraphs: who
we are, why we started, what makes us different — from the owner's words or the About page)
→ coupon ({{coupon}}) → button → footer.

**Plain personal note (A/B arm "personal")**
text only: greeting, 3–4 lines from {SIGNER}, one link in the text, signature. No images.
Looks like a real email from a person — that's the test.

**Service (after purchase)**
header → heading → text → list (what happens now: packing, tracking email, delivery window)
→ text ("just reply to this email") → footer. No code, no selling.

**FAQ / objections**
header → heading → 3–4 pairs of heading(md)+text with the real questions people ask
(shipping, size, returns, payment) → button → footer.

## Subjects and preheaders
Subject ≤ 45 characters, no ALL CAPS, max one emoji. Preheader continues the subject, never
repeats it. The A/B arms differ only in what is being tested.

## Names
"<flow> · <step> · <what>" e.g. "קופה נטושה · E2 · 15%". Keep a map step-id → template id for
the report.

## Starters
`listEmailStarters` has ready designs (cart, Black Friday, fashion, beauty, home...). If one
fits the brand better than the recipes, start from it (`starterId`) and replace the copy, images
and colours.
