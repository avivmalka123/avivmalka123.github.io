# Phone channels: official WhatsApp, regular WhatsApp, SMS (Phases 6–7)

All three only to people who agreed to marketing (Israel: the spam law covers SMS, WhatsApp and
email alike). Ping's consent rule, quiet hours and Shabbat guard stay on.

## §volume · How much will the store send on the phone?
Estimate before choosing, and show the owner the number:
- abandoned checkouts a day = `getCartRecoveryOverview` last-30-days abandoned ÷ 30
- pop-up leads with a phone a day (`listBannerLeads` or 0 for a new pop-up)
- orders a day (`getStoreSales`)
→ "expected automated phone messages a day" ≈ checkouts + leads + orders.

## §whatsapp · Official or regular
| | Official line (Meta API) | Regular number (QR scan) |
|---|---|---|
| Setup | Meta business verification, ~10–20 min of the owner's time | Scan a QR from the phone, 1 min |
| Messages | Approved templates outside 24h, buttons, quick replies | Free text, no buttons, no approval |
| Volume | Grows with the store; campaigns to segments | Low only (below) |
| Risk | Template rejections | WhatsApp may restrict or block a number that sends a lot of automated messages, especially to people who never wrote to it |
Rule here: a regular number fits when the expected automated messages are a few dozen a day at
most (use ≤ 30/day as the line) and it is never used for broadcasts to the list. Above that, or
when the owner wants WhatsApp campaigns: the official line. Say it to the owner in two plain
lines and let them choose; you can start on a regular number and move to official later.

## §mapping · What each phone step becomes
For every WhatsApp step in blueprint.md §4:
- **Official** → the template step exactly as in blueprint.md.
- **Regular WhatsApp** → `kind:"message", channel:"whatsapp", body:<the template's text with the
  variables written as {{name}} {{product}} {{link}} {{link_discount}} {{discount}} {{coupon}} {{order}}>`,
  `shortenLinks:true`, no templateName. Buttons become a line: "תשיבו במספר: 1 המחיר · 2 זמן המשלוח
  · 3 מידה או התאמה · 4 משהו אחר" (the bot reads the number). The link goes in the text.
  Spread volume: keep the flows' delays, don't add extra WhatsApp steps.
- **No WhatsApp** → SMS only on the steps marked SMS below; the other phone steps are dropped
  (the email branch covers them).

## §SMS · Where SMS earns its place
SMS costs allowance (FREE 5, PRO 50, GROWTH 500, PREMIUM 1,000, GOLD/UNLIMITED 2,000 a month;
70 Hebrew / 160 English characters per part). Use it where speed and attention matter:
1. **Checkout abandon** · the 24h T2 step (instead of the WhatsApp offer when there's no
   WhatsApp), and with WhatsApp: one SMS "last chance" at 3 days for people with a phone,
   placed on the `has_phone` yes path after the merge point's WhatsApp, only if the
   allowance covers ~1 SMS per abandoned checkout.
2. **Pop-up phone leads** · the code right away (no WhatsApp) — the lead is waiting for it.
3. **Win-back / VIP** · the code step (no WhatsApp).
4. **Gantt events** · `createSmsCampaign` audience "segment" (VIP, hot segments) for the
   main day and the shipping cut-off of the 2–3 biggest events; `scheduledAt` never on Shabbat.
Before building, estimate SMS a month and compare with `getSmsSettings`; if it doesn't fit,
keep only #1 and the biggest event.
SMS step: `kind:"message", channel:"sms", body:<short text>`, `shortenLinks:true`.
The sender name is the brand in English (`setSmsSenderName`).

## SMS copy (≤ 2 parts; Hebrew stores)
- Checkout T2: "{BRAND}: {{name}}, העגלה שלך שמורה. {T2}% עם הקוד {{discount}}: {{link_discount}}"
- Checkout last: "{BRAND}: הזדמנות אחרונה, {T3}% על העגלה שלך: {{link_discount}}"
- Pop-up code: "{BRAND}: הקוד שלך {{coupon}} מחכה. לקנייה: {{link}}"
- Win-back: "{BRAND}: התגעגענו! {T3}% עם {PFX}LAST{T3}: https://{DOMAIN}/discount/{PFX}LAST{T3}"
- VIP: "{BRAND}: קוד רק ללקוחות VIP: {PFX}VIP{T3}. https://{DOMAIN}/discount/{PFX}VIP{T3}"
- Event: "{BRAND}: {event} מתחיל! {X}% על הכול עד {date}: <link>"
English stores: the same, shorter, e.g. "{BRAND}: your cart is saved. {T2}% off: {{link_discount}}".
Ping adds the opt-out handling; keep the brand name at the start so people know who it is.
