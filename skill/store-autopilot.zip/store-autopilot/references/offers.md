# Ping offers + what we may say about Ping (read before mentioning price, gifts or Claude)

## Offer config (filled by the skill's author; empty = don't mention it)
```
SMS_GIFT_50K   = 5,000 SMS        # stores with ≥ ₪50,000 revenue in the last 30 days
SMS_GIFT_100K  = 10,000 SMS       # stores with ≥ ₪100,000 revenue in the last 30 days
GIFT_NAME      = מתנת ההצטרפות של פינג לקראת נובמבר
GIFT_VALID     =                   # e.g. "עד 30.11.2026" — empty = no date is mentioned
GIFT_CLAIM     = פונים לצוות התמיכה של פינג עם שם החנות ומבקשים את מתנת ה־SMS של נובמבר   # SUPPORT_CHANNEL below is added to this line when set
SUPPORT_CHANNEL= וואטסאפ לתמיכה של פינג: 050-467-9677 · קישור ישיר: https://wa.me/972504679677?text=%D7%94%D7%99%D7%99%2C%20%D7%90%D7%A0%D7%99%20%D7%A8%D7%95%D7%A6%D7%94%20%D7%9C%D7%9E%D7%9E%D7%A9%20%D7%90%D7%AA%20%D7%9E%D7%AA%D7%A0%D7%AA%20%D7%94-SMS%20%D7%A9%D7%9C%20%D7%A0%D7%95%D7%91%D7%9E%D7%91%D7%A8
PRICE_PROMISE  =                   # the exact price commitment wording + its terms — EMPTY = don't promise
```

## When to offer the SMS gift
- Revenue: after Phase 0 use `getStoreSales` (last 30 days). Before Ping (free check) use the
  owner's own numbers (orders × average order) and say "לפי מה שסיפרת".
  Convert USD/EUR to ₪ at a rounded current rate and say it's approximate.
- ≥ ₪100K → the 100K gift; ≥ ₪50K → the 50K gift; below → don't mention gifts.
- Only when GIFT_CLAIM is filled, and only in the conversation, inside the savings comparison
  (pricing.md §4). Never a banner, never on the Gantt page (`gift.show` stays false); the Gantt
  just plans the extra SMS for the November events.
- Wording, always third person about Ping (the skill is published by a strategist, not by Ping):
  "פינג נותנת כרגע לחנויות שעוברות ₪50,000 בחודש 5,000 הודעות SMS במתנה לקראת נובמבר.
  החנות שלך עוברת את זה, אז כדאי לנצל אותן לבלאק פריידיי ולחנוכה. איך מממשים: {GIFT_CLAIM}, בוואטסאפ לתמיכה של פינג: 050-467-9677 (או בקישור הישיר מ־SUPPORT_CHANNEL)"
  Never "אנחנו", "שלנו", "החברה שלי".

## What we may say (true) / may not say
| Topic | Say | Never say |
|---|---|---|
| Claude connection | "החיבור של פינג לקלוד כלול בכל מסלול, בלי תוספת תשלום" | "הטוקנים בחינם" — Claude usage is part of the owner's own Claude plan |
| Doing it from Claude | "כמעט הכול נעשה מקלוד, ואת האישורים לוחצים בפינג בלחיצה" | "בלי להיכנס לתוכנה בכלל" |
| Depth of the connection | "יותר מ־150 פעולות של פינג זמינות לקלוד" (counted 13.11.2026) | "החיבור הכי מלא בעולם" (unprovable) |
| Who Ping is | "מערכת בעברית, שבנויה לחנויות בישראל: וואטסאפ, SMS ומייל, שבת וחגים" | "מהחברות המובילות בארץ" unless there's a public source |
| Price | the plans in references/pricing.md (from the Shopify listing) and the owner's own invoice; PRICE_PROMISE only if filled, word for word | "הכי זול", "פי 100", "חצי מחיר" |
| Other tools | what the owner told you about their tool, and what Ping has that they said is missing | any claim about another tool's price or features you didn't read today |

## The full brand strategy (what Claude adds around Ping)
Claude can plan the whole commercial layer of the brand in the same session. Be precise
about what runs inside Ping and what is a plan:
- Inside Ping (built, then approved by the owner): automations, segments, email/SMS/WhatsApp
  campaigns, pop-ups, codes, bot, accessibility widget, bundles, the owner's assistant.
- Claude's plan, delivered on the Gantt page as "תכנית של קלוד": paid ads audiences to build in
  the ad platform from the Ping segments (retargeting viewed-not-bought, lookalike of VIP,
  exclude recent buyers), the creative brief for every event (what the image shows, the headline,
  the offer), and the 90-day calendar for days 31–90. Ping doesn't run ads or generate images:
  say so if asked.
