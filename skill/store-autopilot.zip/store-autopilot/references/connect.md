# Connecting Ping AI (Phase 0)

The skill can only build inside a Ping AI account. Walk the owner through it step by step,
one step per message, and wait for "done" before the next.

## Step 1 · Install Ping on the store
- Shopify: https://apps.shopify.com/ping-ai → "Install" → approve the permissions →
  finish the short Ping onboarding (store language, email sender).
- In Claude Code you can open it for them: run `open "https://apps.shopify.com/ping-ai"`
  (macOS) / `xdg-open` (Linux) / `start` (Windows). In Claude.ai give the link as a button-like
  line and say: "תלחץ, תתקין, ותחזור לכתוב לי 'סיימתי'".
- Other platforms (WooCommerce etc.): https://pingai.org → sign up → connect the store.
- The free plan is enough to start; the skill will say which automations need a paid plan.

## Step 2 · Connect Ping to Claude
### Claude.ai (web / desktop / mobile)
1. Settings → Connectors → "Add custom connector".
2. Name: `Ping`  ·  URL: `https://pingai.org/api/mcp` → Add.
3. Click Connect → log in with the same account as the store → Allow.
4. In this chat: the tools menu (the sliders icon) → make sure Ping is on.
5. Write "סיימתי".
If Ping still doesn't show up in this chat (a connector added mid-chat often loads only in a new
one), don't troubleshoot: "פותחים צ'אט חדש וכותבים שם: ממשיכים אוטופיילוט. אני ממשיך משם".
Before they go, give the answers so far in one copyable line (store address, max discount,
signer, old tool) so the new chat doesn't ask again.

### Claude Code
```
claude mcp add --transport http ping https://pingai.org/api/mcp
```
Then inside Claude Code run `/mcp`, pick `ping`, authenticate in the browser, and restart the
conversation with "store autopilot".

## Step 3 · Verify
Call `listMyStores`. Success = a store with its name and address. If it still fails:
- "unauthorized" → the login was to a different Ping account than the store's.
- No Ping tools at all → the connector isn't enabled in this chat (step 2.4) or Claude Code
  needs a restart.
- Store list empty → the app install (step 1) didn't finish; open the Ping dashboard once.

## Helpful extras to connect (can be later)
- Email domain (so emails come from the store's own address and land in inbox):
  connections page → email domain → DNS records. Offer to read the records out of
  `getConnections` and explain where to paste them for their DNS host (the result names the host).
- Official WhatsApp line: connections page → WhatsApp → official API (Meta business
  verification). Takes the owner 10–20 minutes; WhatsApp flows are the biggest lift.
Connections page: https://pingai.org/shopify/connections
