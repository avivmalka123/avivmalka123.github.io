#!/usr/bin/env python3
"""Cheapest Ping AI plan for a store's real volume.

Usage: python3 ping_price.py --profiles 12000 --emails 30000 --sms 300 [--usd-ils 3.7]
Prices from the Shopify App Store listing (apps.shopify.com/ping-ai), read 13.11.2026.
Re-check the listing if this file is older than a month.
"""
import argparse, math

PLANS = [  # name, base $, included active profiles, $ per extra 500 profiles, emails, sms
    ("Free",    0.0,    150, None,  10,     5),
    ("Pro",     20.0,   500, 4.0,   5000,   50),
    ("Growth",  44.99, 1000, 5.0,   10000,  500),
    ("Premium", 99.0,  2000, 6.0,   20000,  1000),
    ("Gold",    179.0, 5000, 7.5,   50000,  2000),
]
SMS_OVER = 0.008  # $ per SMS above the allowance

def quote(profiles, emails, sms):
    out = []
    for name, base, inc, per500, em, sm in PLANS:
        if emails > em:            # no email overage is listed: the plan must cover the emails
            continue
        if per500 is None and profiles > inc:
            continue
        extra_blocks = math.ceil(max(0, profiles - inc) / 500)
        extra = extra_blocks * (per500 or 0)
        sms_over = max(0, sms - sm) * SMS_OVER
        total = base + extra + sms_over
        out.append(dict(plan=name, base=base, extra_profiles=extra_blocks * 500, extra_cost=round(extra, 2),
                        sms_over=round(sms_over, 2), total=round(total, 2)))
    return sorted(out, key=lambda r: r["total"])

if __name__ == "__main__":
    a = argparse.ArgumentParser()
    a.add_argument("--profiles", type=int, required=True, help="active profiles the store will message a month")
    a.add_argument("--emails", type=int, required=True, help="emails a month (automations + campaigns)")
    a.add_argument("--sms", type=int, default=0)
    a.add_argument("--usd-ils", type=float, default=0, help="today's rate, to show shekels too")
    x = a.parse_args()
    rows = quote(x.profiles, x.emails, x.sms)
    if not rows:
        print("No listed plan covers this email volume. Check the listing / ask Ping for a custom plan.")
    for r in rows:
        ils = f"  ≈ ₪{r['total'] * x.usd_ils:,.0f}" if x.usd_ils else ""
        print(f"{r['plan']:8} ${r['total']:>8,.2f}/mo{ils}  (base ${r['base']}, +{r['extra_profiles']} profiles ${r['extra_cost']}, SMS over ${r['sms_over']})")
