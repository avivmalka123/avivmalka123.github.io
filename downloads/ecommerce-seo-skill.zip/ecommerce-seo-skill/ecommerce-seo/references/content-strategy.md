# Content Strategy: Blog Content That Sends Organic Traffic to Products

Product and collection pages capture buyers who already know what they want. Blog content captures everyone earlier in the journey and passes them to the products. This is also the content AI answer engines (Google AI Overviews, ChatGPT, Perplexity) quote.

## Topic cluster model

For each main collection:

1. **Pillar guide (1 per collection, 1,500–3,000 words).** "The complete guide to choosing [category]" / "המדריך המלא לבחירת [קטגוריה]". Covers types, what to look for, price ranges, mistakes, FAQ. Links to the collection and to every supporting article.
2. **Supporting articles (10–30 per pillar, 700–1,500 words).** One question or comparison each. Sources for questions: `scripts/keyword_suggest.py` with question prefixes, People Also Ask, Reddit/Facebook groups, customer support, Amazon Q&A.
   Types that work for ecommerce:
   - How to choose / buying guide for a sub-type
   - Best X for Y (list post featuring your products with honest criteria)
   - X vs Y comparison
   - How to use / clean / maintain / fix
   - Is X worth it / does X work
   - Ideas and inspiration (gift ideas, outfit ideas, recipes using the product)
   - Sizing and compatibility guides
   - Problem → solution ("water bottle smells, how to remove it")
3. **Linking rules.** Every supporting article links up to the pillar, sideways to 2–3 sibling articles, and down to 1–3 products or the collection with descriptive anchor text. The pillar links to all children. Products link back to the pillar ("read our guide to choosing…").

## Article structure (also optimized for AI answer engines)

1. **Title (H1):** the question or the promise, keyword included, under 65 characters.
2. **Direct answer in the first 2–3 sentences.** No long intro. AI engines and featured snippets extract this block.
3. **Short "quick answer" or key takeaways box** (3–5 bullets) when the topic is complex.
4. **H2 sections** that each answer one sub-question. Use the phrasing people search as the H2 text.
5. **Tables** for comparisons and specifications. Tables are heavily extracted by Google and AI.
6. **Product mentions in context**, not banners: "for daily commuting we use the [product link] because…". One product card block per article at most, plus text links.
7. **FAQ** with 3–6 questions (FAQPage schema).
8. **Author box** with a real name and one line of credibility, publication date, updated date. Article schema.
9. **Images** with alt text, at least one original (product in use), not only stock.

Length: as long as needed to answer fully, no padding. 900 well-structured words beat 2,500 words of fluff.

## Editorial rules

- Write from the store's expertise: what you learned selling and supporting this product. Generic AI-written text with no specifics does not rank and does not get cited.
- Include concrete numbers, measurements, test results, photos.
- Do not publish 50 articles at once from a template; publish 2–4 per week and update old ones.
- Refresh: every 6–12 months, update facts, add new products, change the "updated" date only when content actually changed.
- Hebrew: write the way Israelis talk; answer the question directly; avoid translated English idioms.

## Internal linking system (site-wide)

- Every new article gets at least 3 inbound links from existing pages within a week (add them manually to related articles, the pillar, and a product description).
- Use a "related articles" block that is HTML (not JS-loaded) on product pages.
- Anchor text: descriptive and varied, includes the target keyword in some but not all links.
- Audit quarterly: articles with zero internal inbound links (orphans) get linked or merged.

## Distribution that supports SEO

- Share each article to Instagram/TikTok/WhatsApp community and email list; early traffic and engagement signals help, and it earns natural links and mentions.
- Pitch the pillar guide to niche blogs, forums, and Israeli content sites for a link.
- Reuse the article as a carousel and a short video; embed the video in the article.

## GEO (Generative Engine Optimization) checklist

- Clear entity: the brand name, what it sells and where, stated in plain text on the home and about pages, plus Organization schema.
- Direct, quotable sentences that stand alone ("An insulated bottle keeps water cold for about 24 hours because…").
- Statistics and sources cited with links.
- Consistent brand information across the site, Google Business Profile, social profiles, marketplaces.
- Reviews and third-party mentions (Reddit, forums, Israeli comparison sites) that mention the brand and product.
- Do not block AI crawlers in robots.txt (GPTBot, PerplexityBot, Google-Extended) if you want to be cited.

## Content plan deliverable

| # | Working title | Primary keyword | Intent | Type | Links to (products / collection) | Priority | Status |
|---|---|---|---|---|---|---|---|

Deliver 1 pillar + 10–15 supporting article rows per collection, prioritized by buying intent and difficulty.
