# Monthly SEO Review (Google Search Console based)

Time needed: 45–60 minutes per month. The student exports or pastes data from GSC; produce the action list.

## Data to collect (last 28 days vs previous 28 days)

1. GSC → Performance → Search results: total clicks, impressions, CTR, average position (with comparison toggle).
2. Performance → Queries: export top 500 (clicks, impressions, CTR, position).
3. Performance → Pages: export top 200.
4. Pages (Indexing) report: not indexed reasons, especially "Not found (404)", "Crawled – currently not indexed", "Duplicate without user-selected canonical", "Excluded by noindex".
5. Enhancements → Product snippets / Merchant listings: errors and warnings.
6. Core Web Vitals: mobile poor URLs.
7. Shopify Analytics: organic sessions and conversion rate (Sessions by traffic source = search).

## Analysis steps

### A. Striking distance keywords
Filter queries: position 5–20, impressions > 50. For each, identify the ranking page (Queries → click query → Pages tab). Actions: add the exact phrase to the page's title or an H2 and FAQ if it is not there, add 2–3 internal links to the page with that anchor, expand the section that answers it. These are the fastest gains.

### B. Low CTR on good positions
Filter: position ≤ 5, CTR < 3% (for non-brand queries). The listing is visible but not clicked. Action: rewrite the SEO title and meta description with a differentiator (price, shipping, quantity, benefit) and check whether a competitor shows rich results (price, rating) that you are missing → fix schema.

### C. Pages losing clicks
Compare periods; pages with a drop > 20%. Check: content changed? product out of stock? redirect? competitor overtook? seasonal? Action per cause: restore, update, redirect, or expand.

### D. Cannibalization
Queries where two of your pages alternate in position. Action: consolidate (merge and 301) or differentiate (give each page a distinct primary keyword and cross-link).

### E. Indexing hygiene
- New 404s on URLs that had traffic → 301 to the best replacement.
- "Crawled – currently not indexed" on products → the content is thin or duplicate; rewrite description and add internal links.
- "Duplicate without user-selected canonical" → check canonical tags on those URLs.
- Product snippet errors → fix in schema (see `schema-templates.md`).

### F. New opportunities
Queries with impressions but no dedicated page (a question your blog does not answer, a product type you sell but have no collection for). Add to the content plan or create the collection.

### G. Technical spot check
Run `python3 scripts/seo_audit.py` on home, top collection, top product. Compare with last month; note regressions (missing H1, schema gone after theme update, alt coverage drop). Theme updates and new apps are the usual cause of regressions.

## Output format

```
## SEO Review – <month>
Clicks: X (±Y%) | Impressions: X (±Y%) | CTR: X% | Avg position: X

### Top 5 actions this month
1. [Page/query] – [action] – [expected effect]
...

### Wins
- ...

### Issues found
- Critical / High / Medium

### Content to publish this month
- [Working title] – [keyword] – [links to]

### Watch list
- Queries/pages to check next month
```

Keep the action list to 5–8 items. A small store that does 5 things every month beats one that plans 40 and does none.
