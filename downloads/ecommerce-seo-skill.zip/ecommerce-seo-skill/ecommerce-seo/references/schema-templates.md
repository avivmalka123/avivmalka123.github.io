# Structured Data (JSON-LD) Templates for Ecommerce

Validate everything at https://search.google.com/test/rich-results and https://validator.schema.org . Only include data that is visible on the page (Google's rule). Never invent ratings or reviews.

## Where to install in Shopify

- Check first: view source of a product page and search for `"@type":"Product"`. Most themes (Dawn and derivatives) already output it. Review apps (Judge.me, Loox) may add another one. Keep exactly one Product schema.
- Site-wide (Organization, WebSite): `layout/theme.liquid` inside `<head>`.
- Per template: `sections/main-product.liquid` (or a new snippet `snippets/schema-product.liquid` included from the product template), `sections/main-collection-banner.liquid` for BreadcrumbList/FAQ, `sections/main-article.liquid` for Article.
- Product FAQs: store questions in a product metafield (list of JSON or rich text) and render both the visible FAQ HTML and the FAQPage JSON-LD from the same metafield, so they always match.

## Product + Offer (+ AggregateRating when real reviews exist)

Liquid version for Shopify (uses live product data):

```liquid
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Product",
  "name": {{ product.title | json }},
  "image": [{% for image in product.images limit: 5 %}{{ image | image_url: width: 1200 | prepend: "https:" | json }}{% unless forloop.last %},{% endunless %}{% endfor %}],
  "description": {{ product.description | strip_html | truncatewords: 60 | json }},
  "sku": {{ product.selected_or_first_available_variant.sku | json }},
  {% if product.selected_or_first_available_variant.barcode != blank %}"gtin13": {{ product.selected_or_first_available_variant.barcode | json }},{% endif %}
  "brand": { "@type": "Brand", "name": {{ product.vendor | json }} },
  "url": {{ shop.url | append: product.url | json }},
  "offers": {
    "@type": "Offer",
    "url": {{ shop.url | append: product.url | json }},
    "priceCurrency": {{ cart.currency.iso_code | json }},
    "price": {{ product.selected_or_first_available_variant.price | money_without_currency | remove: "," | json }},
    "priceValidUntil": "{{ 'now' | date: '%s' | plus: 31536000 | date: '%Y-%m-%d' }}",
    "itemCondition": "https://schema.org/NewCondition",
    "availability": "https://schema.org/{% if product.available %}InStock{% else %}OutOfStock{% endif %}",
    "seller": { "@type": "Organization", "name": {{ shop.name | json }} },
    "shippingDetails": {
      "@type": "OfferShippingDetails",
      "shippingDestination": { "@type": "DefinedRegion", "addressCountry": "IL" },
      "deliveryTime": {
        "@type": "ShippingDeliveryTime",
        "handlingTime": { "@type": "QuantitativeValue", "minValue": 0, "maxValue": 1, "unitCode": "DAY" },
        "transitTime": { "@type": "QuantitativeValue", "minValue": 2, "maxValue": 5, "unitCode": "DAY" }
      }
    },
    "hasMerchantReturnPolicy": {
      "@type": "MerchantReturnPolicy",
      "applicableCountry": "IL",
      "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow",
      "merchantReturnDays": 14,
      "returnMethod": "https://schema.org/ReturnByMail",
      "returnFees": "https://schema.org/FreeReturn"
    }
  }
  {% if product.metafields.reviews.rating_count and product.metafields.reviews.rating_count > 0 %}
  ,"aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": {{ product.metafields.reviews.rating.value.rating | json }},
    "reviewCount": {{ product.metafields.reviews.rating_count | json }}
  }
  {% endif %}
}
</script>
```

Adjust `addressCountry`, shipping days and return days to the store's real policy. Plain JSON version for non-Shopify platforms: replace the Liquid expressions with literal values.

## FAQPage

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "האם הבקבוק נכנס למחזיק כוסות ברכב?",
      "acceptedAnswer": { "@type": "Answer", "text": "כן. קוטר הבסיס 7.4 ס\"מ והוא מתאים למחזיקי כוסות סטנדרטיים." }
    },
    {
      "@type": "Question",
      "name": "Is the bottle dishwasher safe?",
      "acceptedAnswer": { "@type": "Answer", "text": "The body is hand-wash only to protect the insulation; the lid is top-rack dishwasher safe." }
    }
  ]
}
```

Note: since 2023 Google shows FAQ rich results mainly for authoritative government/health sites, but the markup still helps Google and AI engines understand the Q&A, and the visible FAQ content ranks for question queries. Keep it.

## BreadcrumbList

```liquid
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": {{ shop.url | json }} },
    {% if collection %}{ "@type": "ListItem", "position": 2, "name": {{ collection.title | json }}, "item": {{ shop.url | append: collection.url | json }} },{% endif %}
    { "@type": "ListItem", "position": {% if collection %}3{% else %}2{% endif %}, "name": {{ product.title | json }}, "item": {{ shop.url | append: product.url | json }} }
  ]
}
</script>
```

## Organization + WebSite (home page / site-wide)

```json
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://www.example.com/#organization",
      "name": "Store Name",
      "url": "https://www.example.com/",
      "logo": "https://www.example.com/cdn/shop/files/logo.png",
      "contactPoint": { "@type": "ContactPoint", "telephone": "+972-50-0000000", "contactType": "customer service", "availableLanguage": ["he", "en"] },
      "sameAs": ["https://www.instagram.com/store", "https://www.facebook.com/store", "https://www.tiktok.com/@store"]
    },
    {
      "@type": "WebSite",
      "@id": "https://www.example.com/#website",
      "url": "https://www.example.com/",
      "name": "Store Name",
      "publisher": { "@id": "https://www.example.com/#organization" },
      "potentialAction": {
        "@type": "SearchAction",
        "target": { "@type": "EntryPoint", "urlTemplate": "https://www.example.com/search?q={search_term_string}" },
        "query-input": "required name=search_term_string"
      }
    }
  ]
}
```

## Article (blog posts)

```liquid
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": {{ article.title | json }},
  "image": {{ article.image | image_url: width: 1200 | prepend: "https:" | json }},
  "datePublished": {{ article.published_at | date: '%Y-%m-%dT%H:%M:%S%z' | json }},
  "dateModified": {{ article.updated_at | date: '%Y-%m-%dT%H:%M:%S%z' | json }},
  "author": { "@type": "Person", "name": {{ article.author | json }} },
  "publisher": { "@id": "{{ shop.url }}/#organization" },
  "mainEntityOfPage": {{ shop.url | append: article.url | json }},
  "description": {{ article.excerpt_or_content | strip_html | truncatewords: 40 | json }}
}
</script>
```

## ItemList for collection pages (optional)

Lists the products in the collection; helps Google understand the category page.

```liquid
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": {{ collection.title | json }},
  "itemListElement": [
    {% for product in collection.products limit: 20 %}
    { "@type": "ListItem", "position": {{ forloop.index }}, "url": {{ shop.url | append: product.url | json }}, "name": {{ product.title | json }} }{% unless forloop.last %},{% endunless %}
    {% endfor %}
  ]
}
</script>
```

## Common errors and fixes

| Error in Rich Results Test | Fix |
|---|---|
| Missing field "price" / "priceCurrency" | Variant price not output; check the Liquid expression, ensure no thousands separator |
| Either "offers", "review" or "aggregateRating" should be specified | Offers block missing or malformed |
| Duplicate Product markup | Theme and review app both output it; disable one (review apps have a toggle) |
| Invalid value in "availability" | Must be full URL `https://schema.org/InStock` |
| "image" must be a URL | Missing `https:` prefix on Shopify CDN URLs |
| Rating not visible on page | Remove AggregateRating or make reviews visible |
