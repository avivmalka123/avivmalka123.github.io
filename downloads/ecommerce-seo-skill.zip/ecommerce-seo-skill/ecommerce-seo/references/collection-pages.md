# Collection / Category Page SEO

Collections rank for the broad, high-volume terms ("women's running shoes", "מתנות לגבר", "כלי מטבח מעץ"). In most small stores they are an empty grid with a one-word title. Fixing them is usually the fastest organic win.

## Target keyword

- Broad category term, plural, the way buyers type it. Check autocomplete and competitor category names.
- One collection per intent. Do not create three collections ("Bottles", "Water Bottles", "Insulated Bottles") that compete; create one and use sub-collections only if each has 8+ products and its own search demand.
- Automated collections (by tag/vendor/price) are fine technically, but each still needs unique title, description and SEO fields.

## Page structure

1. **H1** = collection title with the keyword: "Women's Running Shoes" not "Women" or "Running".
2. **Intro above the grid (150–300 words, first paragraph contains the keyword).** What is in the collection, for whom, what makes the store's selection worth browsing (curation, price range, shipping). Keep it short above the fold so the products are visible on mobile; a "read more" toggle is acceptable if the full text is in the HTML.
3. **Product grid** with descriptive product titles (they are internal links with anchor text).
4. **Buying guide below the grid (300–800 words).** H2 sections: how to choose, key features to compare, size/material/usage guidance, price ranges, care. Link to 3–6 top products and to relevant blog articles.
5. **FAQ (4–8 questions)** with FAQPage schema.
6. **Links to sibling and child collections** in text, not only in the menu.

Shopify: the collection "Description" field goes above the grid in most themes. For a below-grid section use a theme section (Custom Liquid / Rich text) placed after the product grid, or a metafield rendered by the template. Many themes allow a "collection template" with an extra rich-text block.

## SEO fields

- Page title: `[Category] – [qualifier] | Brand` (50–60 chars). Qualifier examples: "Free Shipping", "Shop 40+ Styles", "מגוון ענק", "משלוח עד הבית".
- Meta description: range + differentiator + shipping/returns + CTA.
- URL handle: `/collections/womens-running-shoes`, `/collections/kitchen-tools-wood`.

## Filters, tags and duplicate URLs

- Tag filter URLs (`/collections/shoes/red`) and filter parameters (`?filter.v.option.color=red`) create near-duplicate pages. Shopify sets the canonical of tag pages to themselves, which can spread ranking signals.
  - Rule of thumb: if the filter combination has real search demand ("red running shoes"), make it a real sub-collection with unique content. Otherwise, add `noindex` to tag pages via `theme.liquid`:
    ```liquid
    {% if template contains 'collection' and current_tags %}
      <meta name="robots" content="noindex, follow">
    {% endif %}
    ```
  - Search & Discovery filters (`?filter.`) are handled by canonical to the base collection in current Shopify; verify with the audit script that the canonical of a filtered URL points to the clean collection URL.
- Sort parameters (`?sort_by=`) must canonicalize to the base URL (Shopify does this by default).
- Pagination (`?page=2`): keep indexable, self-canonical, with the intro text only on page 1 or identical on all pages (both are acceptable). Do not noindex paginated pages, products on page 3 need a crawl path.

## Product URLs inside collections

Shopify links products as `/collections/<handle>/products/<product>`. The canonical on those pages points to `/products/<product>`, which is correct. Improvement: make the theme link directly to `/products/...` (in `product-card` snippets replace `product.url | within: collection` with `product.url`) so internal link equity is not split. This is safe and common.

## Empty and thin collections

- Collections with fewer than 4 products: merge into the parent or noindex until they grow.
- Seasonal collections ("Black Friday 2025"): keep one evergreen URL (`/collections/black-friday`) and update it each year instead of creating a new one.

## Internal linking to collections

- Main menu: all top collections, no more than 7–10 items per level.
- Home page: text links to key collections, not only image tiles without alt text.
- Product pages: breadcrumb to the parent collection plus a text link in the description.
- Blog posts: every guide links to at least one collection.

## Hebrew stores

- Collection names in Hebrew, handles in English (`/collections/gifts-for-men` with title "מתנות לגבר").
- Hebrew broad terms are often gift/occasion-driven ("מתנה ליום הולדת", "מתנה לאמא"). Build occasion collections when the catalog supports them; they carry strong seasonal search demand.
