# Copy Templates and Formulas

## SEO title formulas (50–60 characters)

| Formula | English example | Hebrew example |
|---|---|---|
| Product + Attribute + Brand | Insulated Water Bottle 32 oz – Leakproof \| HydraCo | בקבוק מים תרמי 1 ליטר – שומר קור 24 שעות \| הידרה |
| Product + Audience + Benefit | Running Shoes for Women – Lightweight & Cushioned \| Brand | נעלי ריצה לנשים – קלות ונוחות במיוחד \| מותג |
| Brand + Model + Product type | Dyson V15 Detect Cordless Vacuum \| Store | שואב אבק אלחוטי דייסון V15 \| חנות |
| Product + Quantity/Pack + Offer | Bamboo Toothbrushes 4-Pack – Free Shipping \| Brand | מברשות שיניים במבוק 4 יחידות – משלוח חינם \| מותג |
| Collection: Category + Qualifier + Brand | Women's Running Shoes – Free Returns \| Brand | נעלי ריצה לנשים – מגוון דגמים \| מותג |

Rules: keyword first, brand last, one differentiator, no ALL CAPS, no exclamation marks, no keyword repetition, no "Buy" as the first word unless it is a genuine shopping intent page and it still reads naturally.

## Meta description formulas (140–155 characters)

Structure: `[What it is with keyword] + [main benefit] + [proof/differentiator] + [soft CTA]`.

English: "Insulated stainless steel water bottle that keeps drinks cold 24 h and hot 12 h. Leakproof lid, BPA-free, 2-year warranty. Free shipping over $50."

Hebrew: "בקבוק מים תרמי מנירוסטה ששומר על קור 24 שעות וחום 12 שעות. פקק אטום לדליפות, ללא BPA, שנתיים אחריות. משלוח חינם מעל 199 ₪."

For collections: "[Category] for [audience]: [range/selection], [differentiator], [shipping/returns]. [CTA]."

## H1 formula

`[Product name] – [primary attribute or benefit]`

- "Insulated Water Bottle 32 oz – 24-Hour Cold"
- "בקבוק מים תרמי 1 ליטר – שומר קור 24 שעות"

## Opening paragraph pattern (first 100 words)

`[Primary keyword sentence stating what it is and for whom]. [The single biggest outcome]. [One concrete proof: material, test, number, guarantee].`

English: "This 32 oz insulated water bottle is built for people who spend all day away from a fridge: gym, office, hikes. Double-wall vacuum insulation keeps water ice cold for 24 hours. Food-grade 18/8 stainless steel, no plastic taste, no sweating on your desk."

Hebrew: "בקבוק מים תרמי 1 ליטר שנועד למי שמבלה את כל היום מחוץ לבית: חדר כושר, משרד, טיולים. בידוד ואקום כפול שומר על המים קרים כקרח 24 שעות. נירוסטה 18/8 בדרגת מזון, בלי טעם של פלסטיק ובלי הזעה על השולחן."

## Benefit bullet pattern

`[Feature] so [benefit], which means [why it matters to this buyer].`

- "Wide mouth so ice cubes drop in, which means real cold water at 3 pm, not lukewarm."
- "פיה רחבה כדי שקוביות קרח ייכנסו בקלות, כך שגם בשלוש אחר הצהריים המים עדיין קרים באמת."

## FAQ question sources and pattern

Sources: customer support inbox, WhatsApp questions, Amazon Q&A for a similar product, Google "People also ask", autocomplete with "האם", "איך", "כמה", "is", "does", "how".

Pattern: question exactly as the buyer would type it, answer in 1–3 sentences, first sentence answers directly.

- Q: "Does it fit in a car cup holder?" A: "Yes. The base is 2.9 in (7.4 cm) wide and fits standard car cup holders."
- Q: "האם הבקבוק נכנס למחזיק כוסות ברכב?" A: "כן. קוטר הבסיס 7.4 ס"מ והוא מתאים למחזיקי כוסות סטנדרטיים ברכב."

## Image alt text pattern

`[What is in the image] + [product keyword once on main image] + [distinguishing detail]`

- Main: "Insulated water bottle 32 oz in matte black, front view"
- Lifestyle: "Woman drinking from a black insulated bottle after a run"
- Detail: "Close-up of the leakproof screw lid with carry loop"
- Hebrew main: "בקבוק מים תרמי 1 ליטר בצבע שחור מט, מבט מלפנים"

## URL handle pattern

`product-type-key-attribute` → `insulated-water-bottle-32oz`, `running-shoes-women-lightweight`. For Hebrew stores prefer English transliteration or English keyword handles.

## Anchor text for internal links

- To collection: "see all insulated bottles" / "לכל הבקבוקים התרמיים"
- To product from blog: "the 32 oz insulated bottle we recommend" / "הבקבוק התרמי 1 ליטר שאנחנו ממליצים עליו"
- Avoid: "click here", "this product", raw URLs.

## Hebrew-specific writing notes

- Write like a knowledgeable salesperson in a store, not like a translated catalog. Short sentences.
- Search phrasing in Hebrew often lacks the article and uses the construct form: people type "נעלי ריצה נשים" more than "נעלי ריצה לנשים". Use the natural version in headings and include the typed variation once in the body.
- Units: ס"מ, מ"מ, ק"ג, גרם, ליטר, מ"ל, ₪. Prices with the shekel sign after the number.
- Mixed terms: many Israelis search brand and model in English ("dyson v15", "airpods pro"). Put the English brand/model in the title alongside the Hebrew product type: "אוזניות AirPods Pro 2 – אלחוטיות עם ביטול רעשים".
- Gender: default to masculine plural for general audience copy unless the product is clearly for women, then address in feminine.

## English-specific writing notes

- US vs UK spelling must match the market (color/colour, liter/litre).
- Include imperial and metric where the audience is mixed ("32 oz (950 ml)").
- Avoid superlatives with no proof ("best", "#1") in titles; Google Merchant Center also flags them.
