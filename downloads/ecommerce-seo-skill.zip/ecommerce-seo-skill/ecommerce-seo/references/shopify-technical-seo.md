# Technical SEO for Shopify (with notes for WooCommerce and Wix)

Run `python3 scripts/seo_audit.py <url>` on the home page, one collection, two product pages and one blog post. Then walk through this list.

## What Shopify handles for you (do not "fix")

- Sitemap at `/sitemap.xml` (auto, includes products, collections, pages, blogs). Submit it once in Search Console.
- `robots.txt` (editable via `robots.txt.liquid` since 2021, but the default is sensible).
- Canonical tags on products, collections, sort/filter parameters.
- 301 redirects UI (Online Store → Navigation → URL redirects).
- SSL, CDN, responsive image sizes, lazy loading in modern themes.

## What Shopify cannot change (do not promise the student otherwise)

- URL structure: `/products/`, `/collections/`, `/pages/`, `/blogs/<blog>/` prefixes are fixed. No sub-folders like `/shoes/running/`.
- Only one sitemap; cannot be customized manually.
- Trailing `.myshopify.com` domain must be set to redirect to the primary domain (it is, by default).

## Audit checklist

### Indexing and duplicates
1. Site search `site:yourdomain.com` in Google: are tag pages, `?variant=` URLs, or `/collections/all` variants indexed in bulk? If yes → noindex tag pages (snippet in `collection-pages.md`), verify canonicals.
2. Each product accessible from `/products/<handle>` and internally linked to that URL (not only the collection-nested URL). See `collection-pages.md` → Product URLs.
3. `/collections/all` and `/collections/frontpage`: fine to exist; give them a proper title or keep them out of the menu.
4. Duplicate products (same item published twice for different colors, or test copies "Copy of …") → merge, then 301 the duplicates.
5. Vendor and type pages (`/collections/vendors?q=`, `/collections/types?q=`) are legacy and usually thin; noindex them if they show in `site:` results.

### Redirects and 404s
6. Deleted products and collections: create 301s to the closest replacement or the parent collection. Never leave ranking URLs to 404. Check GSC → Pages → Not found (404).
7. Redirect chains after multiple handle changes (A→B→C): edit to A→C.
8. Old domain or platform migration: import a full redirect map (CSV in Navigation → URL redirects).

### Crawl and structure
9. Every product within 3 clicks from home and in at least one linked collection.
10. Menu: descriptive link text, HTML links (not JS-only mega menu items that are not in the DOM).
11. Breadcrumbs with BreadcrumbList schema.
12. Footer: links to policy pages (shipping, returns, privacy, terms, contact, about). They are trust signals Google reads.

### On-page templates
13. One H1 per template. Check the theme: some put H1 on the logo. Fix in `header.liquid` (change `<h1>` to `<div>` on non-home pages).
14. Title tag pattern in `theme.liquid` includes page title + store name. Do not append long taglines to every page.
15. Meta description falls back to the product/collection description when the SEO field is empty; still fill the SEO field for important pages.
16. Product description rendered as HTML in the initial page load, not injected by an app after click.

### Speed (Core Web Vitals)
17. Test with PageSpeed Insights on mobile for home, collection, product.
18. Biggest Shopify wins: remove unused apps (check Settings → Apps and sales channels, then theme code for leftover scripts after uninstall), compress images before upload, avoid multiple font families, use the theme's native sections instead of page builders where possible, defer non-critical scripts (many themes have a "preload"/"defer" setting).
19. Hero image: upload the correct dimensions; a 4000 px hero scaled down in CSS still costs bytes.
20. Third-party scripts (chat, reviews, popups, pixels) load after the main content; if an app loads a 1 MB bundle on every page, replace it.

### Mobile
21. Tap targets, font size, sticky add to cart, no intrusive popups on entry (Google penalizes interstitials on mobile).

### Structured data
22. Product schema on all products with price, availability, currency, and image. Test 2 products in the Rich Results Test.
23. No duplicate Product schema from theme + review app (common; causes "duplicate field" warnings). Keep one source.
24. Organization schema on home with logo and sameAs (social profiles). BreadcrumbList on collections/products. FAQPage where FAQs exist.

### International / multi-language
25. Shopify Markets with Translate & Adapt or a translation app: verify `hreflang` tags exist per language/country and point to the correct URLs (`/en`, `/he`, or subdomains). Do not translate only the UI and leave product content in one language; those pages are duplicates.
26. Currency selector alone is not international SEO. Different content per market needs different URLs.
27. Israeli stores selling in Hebrew: set store language to Hebrew so `<html lang="he" dir="rtl">` is output; Google uses it.

### Security and basics
28. HTTPS everywhere, no mixed content warnings (images from `http://` in old descriptions).
29. Primary domain set, `www` vs non-`www` redirecting to one version.
30. Search Console verified for the domain property; Bing Webmaster Tools too (imports from GSC in one click).

## Priority framing for the report

- **Critical:** ranking pages returning 404, noindex on money pages, missing/incorrect canonical causing wrong URL to be indexed, product schema with wrong price/availability, site not mobile-usable.
- **High:** collection pages with no content, duplicate products, supplier descriptions site-wide, slow LCP > 4 s, missing internal links to key pages.
- **Medium:** tag pages indexed, missing FAQ schema, images without alt, redirect chains, missing breadcrumbs.
- **Low:** minor title length issues, missing Organization schema, footer link hygiene.

## WooCommerce notes

- Install one SEO plugin (Rank Math or Yoast) for titles, meta, schema, sitemaps. Do not run two.
- URL structure is editable: remove `/product-category/` base via plugin settings if migrating a fresh site; on an existing ranking site leave it.
- Speed depends on hosting and theme: use caching (LiteSpeed/WP Rocket), WebP conversion, limit plugins.
- Product attribute archive pages (`/pa_color/red/`) are usually thin; noindex via the SEO plugin.

## Wix notes

- Wix outputs Product schema and sitemaps automatically; SEO settings per page under "SEO Basics" and "Advanced SEO".
- URL slugs editable per product/category. Category pages have limited content areas; use a text section on the category page for the buying guide.
- Speed is bounded by the platform; focus on image sizes and fewer heavy apps/sections.
