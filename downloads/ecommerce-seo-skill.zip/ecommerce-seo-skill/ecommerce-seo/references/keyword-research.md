# Keyword Research for Ecommerce (no paid tools required)

Goal: a short list of keywords, each mapped to an intent and a page type, that the store can realistically rank for.

## Step 1: Seed list

Collect 5–15 seeds from:
- The product's own name and category ("insulated bottle", "בקבוק תרמי").
- How customers describe it in messages and reviews (their words, not the supplier's).
- Competitor product and collection titles (open the top 3 ranking stores, copy their H1s and page titles).
- Marketplace search bars: type the product in Amazon, AliExpress, eBay, Zap (Israel), KSP, and note the autocomplete suggestions. Marketplace autocomplete reflects buyer language.

## Step 2: Expand with Google autocomplete

Run the bundled script:

```
python3 scripts/keyword_suggest.py "בקבוק תרמי" --lang he --country il
python3 scripts/keyword_suggest.py "insulated water bottle" --lang en --country us
```

It queries Google autocomplete for the seed plus a–z (or א–ת) suffixes and question/modifier prefixes ("best", "how to", "vs", "for", "איך", "האם", "כמה", "מומלץ") and prints the unique suggestions. Autocomplete only shows queries with real volume, so everything it returns is searched.

Without network access, do the same manually in an incognito window and note "People also ask" and "Related searches" at the bottom of the results page.

## Step 3: Classify intent

| Intent | Signals in the query | Target page |
|---|---|---|
| Transactional | buy, price, cheap, near me, shop, order, מחיר, לקנות, זול, משלוח | Product or collection |
| Commercial investigation | best, top, review, vs, comparison, recommended, מומלץ, הכי טוב, השוואה, ביקורת | Collection with buying guide, or blog "best X" post linking to products |
| Informational | how, what, why, can, does, is, guide, ideas, איך, מה, למה, האם, רעיונות | Blog post that links to products |
| Navigational | brand or store name | Home / brand page |

## Step 4: Check the SERP before committing

For each candidate keyword, search it and look at what ranks:
- All results are Amazon, marketplaces and big brands → a small store will not outrank them on that head term. Go one level more specific (add attribute, audience, use case) or target the question queries around it.
- Results are blog posts and guides → the intent is informational; a product page will not rank, write an article.
- Results are collection pages of mid-size stores → good target for a collection.
- Shopping carousel and product grids appear → product page with good schema and Merchant Center can appear there.
- Local results appear (map pack) → the query has local intent; consider a Google Business Profile.

## Step 5: Prioritize

Score each keyword 1–3 on: relevance to what the store sells, realistic difficulty (from the SERP check), buying intent. Sum and sort. Deliver the top 10–20 as:

| Keyword | Intent | Page type | Existing page (URL or "new") | Priority |
|---|---|---|---|---|

Rule: primary keyword for a product = specific, transactional. Primary for a collection = broad, commercial/transactional. Everything informational → content plan (see `content-strategy.md`).

## Step 6: Use Search Console when the store already has traffic

In GSC → Performance → Queries, filter the last 3 months:
- Queries with position 5–20 and >50 impressions = striking distance. Strengthen the page already ranking (add the phrase to title/H2/FAQ, add internal links to it).
- Queries where the ranking page is the wrong type (a blog post ranking for a product term) = build or improve the correct page and link to it.
- Queries the store did not intend to target but gets impressions for = new content or new collection ideas.

## Long tail and modifiers cheat sheet

Attribute modifiers: size, color, material, capacity, quantity, model year, compatibility ("for iPhone 16").
Audience: for women / men / kids / babies / seniors / dogs; לנשים / לגברים / לילדים / לתינוקות.
Use case: for travel / gym / office / hiking / gift; לטיול / לחדר כושר / למשרד / למתנה.
Occasion (very strong in Hebrew): מתנה ליום הולדת, מתנה לחג, מתנה לאמא, לחתונה, לגן.
Comparison: X vs Y, X or Y, alternative to X.
Problem: leaking, not working, how to clean, how to fix.

## What not to do

- Do not chase a single volume number from a tool as if it were truth; autocomplete presence plus SERP shape is more reliable for a small store.
- Do not target the same keyword with two pages.
- Do not translate English keyword lists into Hebrew word for word; research Hebrew phrasing directly, the word order and vocabulary differ.
