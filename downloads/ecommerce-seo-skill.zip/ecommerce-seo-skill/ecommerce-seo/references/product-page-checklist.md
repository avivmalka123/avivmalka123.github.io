# Product Page SEO Checklist

Use this checklist for every product page. Work top to bottom; the order is the order of impact.

## 1. Keyword targeting

- One primary keyword per product. Formula: `[product type] + [key attribute]` or `[brand] + [model]`.
  - Hebrew example: "בקבוק מים תרמי 1 ליטר" (primary), variations: "בקבוק תרמי לספורט", "בקבוק שומר קור 24 שעות".
  - English example: "insulated water bottle 32 oz" (primary), variations: "stainless steel water bottle", "leak proof sports bottle".
- 3–6 secondary keywords: synonyms, use cases, audience ("לילדים", "for hiking"), material, size, color when people search by it.
- Confirm that no collection page or blog post already targets the same primary keyword. If it does, choose a more specific term for the product.

## 2. SEO title (Shopify: Search engine listing → Page title)

- 50–60 characters. Google truncates around 600 pixels; Hebrew letters are narrower, so 55–65 Hebrew characters usually fit.
- Primary keyword in the first half. Brand last, separated by `|` or `-`.
- Add one differentiator that earns the click: free shipping, quantity, warranty, "original", size range.
- Do not repeat the same word twice. Do not use ALL CAPS. Do not stuff a list of keywords.

## 3. Meta description (Shopify: Search engine listing → Description)

- 140–155 characters. Not a ranking factor, but it drives CTR, which matters.
- Structure: what it is + the main benefit + a proof or differentiator + a soft call to action.
- Include the primary keyword once (Google bolds matching terms).
- Mention shipping time, returns or warranty if they are real advantages.

## 4. URL handle

- Short, lowercase, hyphens, primary keyword, no dates, no color/size variants, no stop words.
- Good: `/products/insulated-water-bottle-32oz`. Bad: `/products/copy-of-new-arrival-bottle-blue-2024-1`.
- Hebrew stores: Shopify allows Hebrew handles, but they become percent-encoded in shares and analytics. Prefer English transliteration or English keyword for the handle; keep the Hebrew in the title and H1.
- Never change the handle of a product that already ranks or has backlinks unless a 301 redirect is created (Shopify adds it automatically when the "Create a URL redirect" box is checked; verify).

## 5. H1

- Exactly one H1 on the page: the product title. Include the primary keyword naturally.
- Shopify product title = H1 in almost all themes, so write the product title as `[Product name] – [main attribute/benefit]`, not just a model code.
- Do not use the H1 for promotional text ("SALE!!!").

## 6. Product description (300–600 words for standard products, 600–1,000 for high-consideration products)

Write in this order. Use H2/H3 headings for the sections so Google sees the structure.

1. **Opening paragraph (2–3 sentences, primary keyword in the first 100 words).** Who it is for and the single biggest outcome. Not "Introducing our amazing…".
2. **Key benefits (3–5 bullets).** Each bullet = feature → benefit → why it matters. Include secondary keywords here.
3. **Specifications table.** Material, dimensions, weight, capacity, compatibility, what is in the box. Tables help Google extract facts and help buyers compare.
4. **How to use / setup (short).** Optional but strong for gadgets, cosmetics, supplements.
5. **Who it is for / who should skip it.** Honest fit reduces returns and reads as trustworthy content.
6. **FAQ (4–6 questions).** Use real questions from customer support, Amazon Q&A, People Also Ask. Answer in 1–3 sentences each. Mark up with FAQPage schema.
7. **Shipping, returns, warranty (2–3 lines).** Link to the policy pages.

Rules:
- Unique text. Never paste the supplier description. If the store has 200 products with supplier text, prioritize rewriting the 20 that get the most impressions in Search Console.
- Write in the store language only. For Hebrew: use natural spoken Hebrew, not machine-translated Hebrew; keep sizes and units in the format Israelis use (ס"מ, ק"ג, ליטר).
- Do not hide text, do not repeat the keyword more than it naturally appears (roughly 3–6 times in 500 words).
- Variants (colors, sizes) belong in the variant selector, not repeated as separate paragraphs.

## 7. Images

- File name before upload: `insulated-water-bottle-32oz-black.jpg`, not `IMG_2041.jpg` or `H8c2a1.jpg` (Shopify keeps the original file name in the CDN URL).
- Alt text on every image: describe the image + include the keyword once on the main image. Example: "בקבוק מים תרמי 1 ליטר בצבע שחור על שולחן עץ". Do not write "image", "photo", or keyword lists.
- 5–8 images: main on white, lifestyle, scale/size reference, detail, packaging, infographic with specs.
- Compress: WebP or JPEG under 200 KB for product images; Shopify serves responsive sizes automatically but the source should not be 5 MB.
- Add a short video if available; embed from Shopify files, not an app that injects heavy scripts.

## 8. Reviews and trust

- Real reviews on the page with AggregateRating schema (only when reviews exist and are visible).
- Review apps: Judge.me, Loox, Yotpo. Make sure the app renders reviews as HTML (not only inside an iframe) so Google can read them.
- Trust elements near the price: shipping time, return policy, secure payment, contact details.

## 9. Internal links

- Link from the description to: the parent collection, 1–2 related products, one blog guide.
- Anchor text descriptive ("see all insulated bottles"), not "click here".
- Breadcrumbs: Home → Collection → Product, with BreadcrumbList schema.
- Make sure the product is reachable within 3 clicks from the home page and is in at least one collection linked from the main menu.

## 10. Structured data

- Product schema with name, image, description, sku, brand, offers (price, currency, availability, url), aggregateRating and review when real.
- Most Shopify themes output Product schema. Check with the audit script or the Rich Results Test. If missing or incomplete, add it (see `schema-templates.md`).
- FAQPage schema for the FAQ block.

## 11. Google Merchant Center (free listings)

- Connect the store to Merchant Center (Shopify: Google & YouTube app). Free product listings appear in the Shopping tab and product knowledge panels.
- Title in the feed = Shopify product title. Optimize it for shopping queries: `[Brand] [Product type] [Key attribute] [Size/Color]`.
- Fix feed disapprovals (missing GTIN, price mismatch, shipping settings) — they also hurt organic shopping visibility.

## 12. Page speed and UX

- Product page LCP under 2.5 s on mobile. Main causes on Shopify: too many apps, uncompressed hero image, slider libraries, third-party fonts.
- Remove apps that are not used. Each app usually injects scripts on every page.
- Sticky add-to-cart on mobile, visible price and shipping before the fold.

## Common mistakes to flag

- Product title is only a model code ("XZ-200") with no product type.
- Same description on 10 color variants published as separate products (merge into one product with variants, 301 the rest).
- Out-of-stock products deleted instead of kept with "notify me" or redirected to the closest product/collection.
- Multiple H1s (theme puts H1 on the logo and on the title).
- Description entirely inside an image or a tab that loads via JavaScript after click (Google may not index it).
- Keyword only in English while the customers search in Hebrew, or vice versa.
