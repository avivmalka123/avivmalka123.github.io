---
name: ecommerce-seo
description: This skill should be used when the user wants to improve organic (SEO) visibility of products, collections or blog content on a Shopify store or any other ecommerce site (WooCommerce, Wix, custom). Trigger on requests like "optimize this product page for SEO", "write SEO title and meta description", "keyword research for my product", "why isn't my product ranking", "SEO audit of my store", "schema markup for products", "blog posts that bring traffic to my products", or the Hebrew equivalents ("קידום אורגני", "SEO לחנות", "תכתוב לי תיאור מוצר מקודם", "מילות מפתח למוצר", "למה המוצר לא מופיע בגוגל", "אודיט SEO"). Also trigger when the user pastes a product URL and asks how to get more free traffic to it.
---

# Ecommerce SEO (Shopify and any ecommerce site)

## Purpose

Turn a product, collection or store into pages that Google (and AI search engines) can understand, rank and show in shopping results. The skill covers the full loop: keyword research, product page optimization, collection pages, technical Shopify SEO, structured data (schema), images, internal linking, supporting blog content, and a repeatable monthly audit.

Write all customer-facing output (titles, descriptions, blog copy) in the store's language. If the store is Hebrew, write Hebrew copy with the right-to-left conventions and Hebrew search phrasing. If the store sells in English, write native English. Never mix languages inside a title or meta description.

## Core principles (apply to every task)

1. **One page = one primary keyword + a cluster of variations.** Never target the same primary keyword on two pages (product vs. collection vs. blog). Collections take the broad term ("נעלי ריצה לנשים" / "women's running shoes"), products take the specific term (brand + model + attribute), blog posts take the questions.
2. **Search intent first.** Product and collection pages win on transactional and commercial queries. Informational queries ("how to choose…", "איך לבחור…") go to blog posts that link to the product. Do not stuff informational content into a product page.
3. **Unique content per page.** Supplier descriptions copied from AliExpress or the manufacturer are duplicated across thousands of stores and do not rank. Every product needs its own description.
4. **The description sells and ranks at the same time.** Structure: hook for the buyer, benefits, specifications, who it is for / not for, FAQ, shipping and returns. Keywords land naturally in the H1, first 100 words, one H2, image alt text and the FAQ.
5. **Technical hygiene before content volume.** Fix canonicals, duplicate URLs, speed, broken links and thin collections before writing 50 blog posts.
6. **Measure in Google Search Console.** Every recommendation should map to a query, page or issue the student can watch in GSC.

## Workflows

Pick the workflow that matches the request. Read the linked reference file before executing; each one has the detailed checklist, formulas and examples.

### Workflow 1: Optimize a single product page

Use when the user gives a product URL, product name, or pastes a description.

1. If a URL is given and network access is available, run the audit script first:
   `python3 scripts/seo_audit.py <url>` (prints title, meta, H1s, headings, image alt coverage, canonical, schema found, word count, internal links).
2. Identify the primary keyword and 3–6 secondary keywords. If the user did not give them, follow `references/keyword-research.md` (run `python3 scripts/keyword_suggest.py "<seed>" --lang he` or `--lang en` for autocomplete expansion).
3. Rewrite using the formulas in `references/copy-templates.md`:
   - SEO title (50–60 characters, primary keyword near the start, brand at the end)
   - Meta description (140–155 characters, benefit + differentiator + call to action)
   - H1 (product name + main attribute, one H1 only)
   - URL handle (short, keyword, hyphens, no stop words, never change an existing ranking URL without a 301)
   - Product description (300–600 words, structure from `references/product-page-checklist.md`)
   - Image alt texts and file names
   - FAQ block (4–6 real buyer questions)
4. Produce Product + Offer + FAQPage JSON-LD from `references/schema-templates.md` if the theme does not already output it (check with the audit script; Shopify themes usually output Product schema, most do not output FAQPage).
5. Deliver the result using `assets/product-seo-brief-template.md` so the student can paste each field into Shopify admin (Title, Description, Search engine listing, Image alt, URL handle).

### Workflow 2: Optimize a collection / category page

Collections are the highest-leverage SEO pages in most stores and are usually empty. Follow `references/collection-pages.md`: choose the broad keyword, write a 150–300 word intro above the grid and a 300–800 word buying guide below the grid, add FAQ, internal links to sub-collections and top products, and handle filter/tag URL duplication.

### Workflow 3: Keyword research for a product or niche

Follow `references/keyword-research.md`. Deliver a table: keyword, intent (transactional / commercial / informational), target page type (product / collection / blog), priority. No paid tool is required; the method uses Google autocomplete (`scripts/keyword_suggest.py`), People Also Ask, competitor titles, marketplace search terms (Amazon, AliExpress, eBay) and Google Search Console data when the user has it.

### Workflow 4: Technical SEO audit of a Shopify store

Follow `references/shopify-technical-seo.md`. Cover: duplicate product URLs under `/collections/.../products/...`, canonical tags, tag and filter pages, pagination, sitemap and robots.txt, redirects for deleted products, speed (apps, images, theme), mobile, HTTPS, hreflang for multi-language stores, and the Shopify-specific limitations (URL structure cannot be changed, `/products/` prefix is fixed). Run `scripts/seo_audit.py` on the home page, one collection and two products, then report findings as a prioritized list: critical, high, medium, low.

### Workflow 5: Content that sends organic traffic to products

Follow `references/content-strategy.md`. Build a topic cluster: one pillar guide per collection, 10–30 supporting question articles, each linking to the pillar and to 1–3 products with descriptive anchor text. Include the internal-linking rules and the article structure that also gets cited by AI answer engines (direct answer in the first paragraph, clear headings, FAQ, author and date).

### Workflow 6: Schema markup

Follow `references/schema-templates.md`. Provide Product, Offer, AggregateRating (only with real reviews), BreadcrumbList, FAQPage, Organization and, for blog posts, Article JSON-LD. Explain where to paste it in Shopify (theme.liquid or a section, or a metafield-driven snippet) and how to validate it (Google Rich Results Test, Schema.org validator).

### Workflow 7: Monthly SEO review

Follow `references/monthly-audit.md`. Read GSC data the user pastes (queries, pages, CTR, position), find "striking distance" keywords (position 5–20), pages with high impressions and low CTR (rewrite title/meta), pages losing clicks, new 404s, and produce a short action list for the month.

## Output format rules

- Always deliver copy-paste-ready fields, labeled the way they appear in the Shopify admin ("Title", "Description", "Search engine listing → Page title", "Meta description", "URL handle", "Image alt text").
- Count characters for titles and meta descriptions and show the count.
- When suggesting keywords, state the intent and the page type that should target each one.
- When something cannot be verified (no network access, no GSC data), state it and give the student the exact check to run themselves.
- Keep it practical for a small store owner: no enterprise tooling, no vague "improve E-E-A-T" advice without concrete steps.

## Resources

### scripts/
- `seo_audit.py` — on-page audit of any URL (stdlib only, no installs). Usage: `python3 scripts/seo_audit.py <url> [--json]`.
- `keyword_suggest.py` — expands a seed keyword with Google autocomplete (a–z, question and modifier prefixes). Usage: `python3 scripts/keyword_suggest.py "<seed>" --lang he|en [--country il|us] [--json]`.

### references/
- `product-page-checklist.md` — full on-page checklist and description structure for product pages.
- `copy-templates.md` — title, meta, H1, alt-text and description formulas with Hebrew and English examples.
- `collection-pages.md` — collection/category page optimization and filter/tag duplication handling.
- `keyword-research.md` — free keyword research method and intent classification.
- `shopify-technical-seo.md` — Shopify-specific technical SEO, plus notes for WooCommerce and Wix.
- `schema-templates.md` — JSON-LD templates and where to install them.
- `content-strategy.md` — topic clusters, blog article structure, internal linking, AI-search (GEO) rules.
- `monthly-audit.md` — Search Console based monthly review procedure.

### assets/
- `product-seo-brief-template.md` — the deliverable template for a single product optimization.
