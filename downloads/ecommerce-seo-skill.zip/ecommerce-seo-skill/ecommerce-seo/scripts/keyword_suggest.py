#!/usr/bin/env python3
"""
Expand a seed keyword with Google Autocomplete suggestions.
Standard library only. Every suggestion returned is a query people actually type.

Usage:
    python3 keyword_suggest.py "בקבוק תרמי" --lang he --country il
    python3 keyword_suggest.py "insulated water bottle" --lang en --country us
    python3 keyword_suggest.py "running shoes" --lang en --json
Options:
    --lang he|en        interface language (default: auto-detect from seed)
    --country il|us|gb  country code (default: il for Hebrew, us otherwise)
    --no-alpha          skip the a–z / א–ת suffix expansion (faster)
    --json              JSON output
"""
import json
import sys
import time
import urllib.parse
import urllib.request

HE_LETTERS = list("אבגדהוזחטיכלמנסעפצקרשת")
EN_LETTERS = list("abcdefghijklmnopqrstuvwxyz")

PREFIXES = {
    "he": ["איך", "האם", "כמה", "מה", "למה", "איזה", "מומלץ", "הכי טוב", "השוואה", "לעומת", "ביקורת", "מחיר", "זול", "מתנה"],
    "en": ["how to", "is", "does", "can", "what", "why", "which", "best", "top", "vs", "review", "cheap", "price", "for"],
}
SUFFIXES = {
    "he": ["לנשים", "לגברים", "לילדים", "לתינוקות", "לטיול", "למשרד", "לחדר כושר", "מתנה", "מחיר", "מומלץ", "או", "לעומת", "בעיה", "לא עובד", "ניקוי"],
    "en": ["for women", "for men", "for kids", "for travel", "for gym", "for office", "gift", "price", "near me", "or", "vs", "not working", "cleaning", "size", "review"],
}


def detect_lang(s):
    return "he" if any("֐" <= ch <= "׿" for ch in s) else "en"


def suggest(q, lang, country):
    params = urllib.parse.urlencode({"client": "firefox", "q": q, "hl": lang, "gl": country})
    url = "https://suggestqueries.google.com/complete/search?" + params
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8", errors="replace"))
        return data[1] if isinstance(data, list) and len(data) > 1 else []
    except Exception:
        return []


def expand(seed, lang, country, alpha=True, delay=0.15):
    queries = [seed]
    letters = HE_LETTERS if lang == "he" else EN_LETTERS
    if alpha:
        queries += [f"{seed} {l}" for l in letters]
    queries += [f"{p} {seed}" for p in PREFIXES[lang]]
    queries += [f"{seed} {s}" for s in SUFFIXES[lang]]
    seen, results = set(), []
    for q in queries:
        for s in suggest(q, lang, country):
            s = " ".join(s.split())
            if s and s.lower() not in seen:
                seen.add(s.lower())
                results.append({"keyword": s, "from": q})
        time.sleep(delay)
    return results


def classify(kw, lang):
    k = kw.lower()
    info = ["איך", "האם", "כמה", "מה ", "למה", "איזה", "how", "what", "why", "does", "is ", "can ", "guide", "ideas", "רעיונות", "מדריך"]
    comm = ["מומלץ", "הכי טוב", "השוואה", "לעומת", "ביקורת", "best", "top", "vs", "review", "compare", "alternative"]
    trans = ["מחיר", "לקנות", "זול", "משלוח", "מבצע", "buy", "price", "cheap", "shop", "order", "near me", "sale", "deal"]
    if any(w in k for w in trans):
        return "transactional"
    if any(w in k for w in comm):
        return "commercial"
    if any(k.startswith(w) or f" {w}" in k for w in info):
        return "informational"
    return "transactional/commercial"


if __name__ == "__main__":
    argv = sys.argv[1:]
    seeds = [a for a in argv if not a.startswith("--")]
    if not seeds:
        print(__doc__)
        sys.exit(1)
    seed = seeds[0]

    def opt(name, default=None):
        if name in argv:
            i = argv.index(name)
            return argv[i + 1] if i + 1 < len(argv) else default
        return default

    lang = opt("--lang") or detect_lang(seed)
    country = opt("--country") or ("il" if lang == "he" else "us")
    alpha = "--no-alpha" not in argv
    rows = expand(seed, lang, country, alpha=alpha)
    for r in rows:
        r["intent"] = classify(r["keyword"], lang)
    if "--json" in argv:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
    else:
        print(f"\n{len(rows)} unique suggestions for '{seed}' (lang={lang}, country={country})\n")
        by = {}
        for r in rows:
            by.setdefault(r["intent"], []).append(r["keyword"])
        for intent in ("transactional", "commercial", "transactional/commercial", "informational"):
            if intent in by:
                print(f"## {intent} ({len(by[intent])})")
                for k in by[intent]:
                    print(f"  - {k}")
                print()
        if not rows:
            print("No suggestions returned. Check network access, or run the searches manually in an incognito window.")
