#!/usr/bin/env python3
"""
On-page SEO audit for a single URL (product, collection, blog post, home page).
Standard library only. No installs needed.

Usage:
    python3 seo_audit.py https://store.com/products/some-product
    python3 seo_audit.py https://store.com/collections/shoes --json
"""
import json
import re
import sys
import urllib.request
import urllib.parse
from html.parser import HTMLParser


class PageParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.title = ""
        self.meta = {}
        self.canonical = ""
        self.hreflang = []
        self.headings = []  # (level, text)
        self.images = []  # dict(src, alt)
        self.links = []  # dict(href, text)
        self.jsonld = []
        self.lang = ""
        self.text_chunks = []
        self._in_title = False
        self._heading_level = None
        self._heading_buf = []
        self._in_script_ld = False
        self._script_buf = []
        self._in_a = False
        self._a_href = ""
        self._a_buf = []
        self._skip = 0  # inside script/style/noscript

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html":
            self.lang = a.get("lang", "")
        elif tag == "title":
            self._in_title = True
        elif tag == "meta":
            name = (a.get("name") or a.get("property") or "").lower()
            if name:
                self.meta[name] = a.get("content", "")
        elif tag == "link":
            rel = (a.get("rel") or "").lower()
            if rel == "canonical":
                self.canonical = a.get("href", "")
            elif rel == "alternate" and a.get("hreflang"):
                self.hreflang.append((a.get("hreflang"), a.get("href")))
        elif tag in ("h1", "h2", "h3"):
            self._heading_level = tag
            self._heading_buf = []
        elif tag == "img":
            src = a.get("src") or a.get("data-src") or a.get("srcset", "").split(" ")[0]
            self.images.append({"src": src, "alt": a.get("alt")})
        elif tag == "a":
            self._in_a = True
            self._a_href = a.get("href", "")
            self._a_buf = []
        elif tag == "script":
            if (a.get("type") or "").lower() == "application/ld+json":
                self._in_script_ld = True
                self._script_buf = []
            self._skip += 1
        elif tag in ("style", "noscript"):
            self._skip += 1

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag in ("h1", "h2", "h3") and self._heading_level == tag:
            self.headings.append((tag, " ".join("".join(self._heading_buf).split())))
            self._heading_level = None
        elif tag == "a" and self._in_a:
            self.links.append({"href": self._a_href, "text": " ".join("".join(self._a_buf).split())})
            self._in_a = False
        elif tag == "script":
            if self._in_script_ld:
                raw = "".join(self._script_buf).strip()
                try:
                    self.jsonld.append(json.loads(raw))
                except Exception:
                    self.jsonld.append({"_parse_error": raw[:120]})
                self._in_script_ld = False
            self._skip = max(0, self._skip - 1)
        elif tag in ("style", "noscript"):
            self._skip = max(0, self._skip - 1)

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if self._in_script_ld:
            self._script_buf.append(data)
            return
        if self._skip:
            return
        if self._heading_level:
            self._heading_buf.append(data)
        if self._in_a:
            self._a_buf.append(data)
        if data.strip():
            self.text_chunks.append(data)


def fetch(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; EcomSEOAudit/1.0; +https://example.com)",
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "he,en;q=0.8",
    })
    with urllib.request.urlopen(req, timeout=25) as r:
        final_url = r.geturl()
        status = r.status
        body = r.read()
        ctype = r.headers.get("Content-Type", "")
    m = re.search(r"charset=([\w-]+)", ctype)
    enc = m.group(1) if m else "utf-8"
    try:
        html = body.decode(enc, errors="replace")
    except LookupError:
        html = body.decode("utf-8", errors="replace")
    return status, final_url, html, len(body)


def schema_types(jsonld):
    types = []

    def walk(node):
        if isinstance(node, dict):
            t = node.get("@type")
            if t:
                types.extend(t if isinstance(t, list) else [t])
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(jsonld)
    return types


def product_schema_check(jsonld):
    """Return list of issues in Product schema, or None if no Product schema."""
    products = []

    def walk(node):
        if isinstance(node, dict):
            t = node.get("@type")
            tl = t if isinstance(t, list) else [t]
            if "Product" in tl or "ProductGroup" in tl:
                products.append(node)
                return  # do not count variants nested under hasVariant
            for k, v in node.items():
                if k in ("hasVariant", "isVariantOf"):
                    continue
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(jsonld)
    if not products:
        return None
    # ProductGroup: merge first variant's offer/sku into the group for the field checks
    for p0 in products:
        t = p0.get("@type")
        tl = t if isinstance(t, list) else [t]
        if "ProductGroup" in tl and not p0.get("offers"):
            variants = p0.get("hasVariant") or []
            if variants and isinstance(variants[0], dict):
                v0 = variants[0]
                for f in ("offers", "sku", "gtin13", "gtin", "mpn", "image"):
                    if not p0.get(f) and v0.get(f):
                        p0[f] = v0[f]
    issues = []
    if len(products) > 1:
        issues.append(f"{len(products)} Product schema blocks found (should be exactly 1)")
    p = products[0]
    for f in ("name", "image", "description", "offers"):
        if not p.get(f):
            issues.append(f"Product schema missing '{f}'")
    if not p.get("brand"):
        issues.append("Product schema missing 'brand'")
    if not (p.get("sku") or p.get("gtin13") or p.get("gtin") or p.get("mpn")):
        issues.append("Product schema has no sku/gtin/mpn")
    offers = p.get("offers")
    if offers:
        o = offers[0] if isinstance(offers, list) else offers
        for f in ("price", "priceCurrency", "availability"):
            if not o.get(f) and not (f == "price" and o.get("lowPrice")):
                issues.append(f"Offer missing '{f}'")
        if not o.get("shippingDetails"):
            issues.append("Offer has no shippingDetails (recommended for merchant listings)")
        if not o.get("hasMerchantReturnPolicy"):
            issues.append("Offer has no hasMerchantReturnPolicy (recommended)")
    if "AggregateRating" not in schema_types(jsonld):
        issues.append("No aggregateRating (fine if there are no visible reviews)")
    return issues


def audit(url):
    status, final_url, html, size = fetch(url)
    p = PageParser()
    p.feed(html)

    host = urllib.parse.urlparse(final_url).netloc
    internal, external = [], []
    for l in p.links:
        href = l["href"]
        if not href or href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue
        full = urllib.parse.urljoin(final_url, href)
        (internal if urllib.parse.urlparse(full).netloc == host else external).append({"href": full, "text": l["text"]})

    text = " ".join(" ".join(p.text_chunks).split())
    words = len(text.split())
    h1s = [t for lvl, t in p.headings if lvl == "h1"]
    h2s = [t for lvl, t in p.headings if lvl == "h2"]
    h3s = [t for lvl, t in p.headings if lvl == "h3"]
    imgs = [i for i in p.images if i["src"] and not i["src"].startswith("data:")]
    missing_alt = [i for i in imgs if not (i["alt"] or "").strip()]
    types = schema_types(p.jsonld)
    prod_issues = product_schema_check(p.jsonld)
    robots = p.meta.get("robots", "")
    title = " ".join(p.title.split())
    desc = p.meta.get("description", "")

    collection_nested = [l for l in internal if "/collections/" in l["href"] and "/products/" in l["href"]]
    generic_anchors = [l for l in internal if l["text"].lower() in ("click here", "here", "read more", "לחץ כאן", "כאן", "קרא עוד", "למידע נוסף")]

    findings = []
    def add(level, msg):
        findings.append({"level": level, "msg": msg})

    if status != 200:
        add("critical", f"HTTP status {status}")
    if "noindex" in robots.lower():
        add("critical", f"Page is noindex (meta robots: {robots})")
    if not p.canonical:
        add("high", "No canonical tag")
    elif urllib.parse.urlparse(p.canonical).path.rstrip("/") != urllib.parse.urlparse(final_url).path.rstrip("/"):
        add("medium", f"Canonical points elsewhere: {p.canonical}")
    if not title:
        add("critical", "Missing <title>")
    elif len(title) > 65:
        add("medium", f"Title is {len(title)} chars (aim 50–60)")
    elif len(title) < 30:
        add("medium", f"Title is only {len(title)} chars (aim 50–60)")
    if not desc:
        add("high", "Missing meta description")
    elif len(desc) > 165:
        add("low", f"Meta description is {len(desc)} chars (aim 140–155)")
    elif len(desc) < 80:
        add("medium", f"Meta description is only {len(desc)} chars (aim 140–155)")
    if len(h1s) == 0:
        add("high", "No H1")
    elif len(h1s) > 1:
        add("medium", f"{len(h1s)} H1 tags (should be 1): {h1s}")
    if not h2s:
        add("medium", "No H2 headings (description has no structure)")
    if "/products/" in final_url and words < 300:
        add("high", f"Thin content: ~{words} words on a product page (aim 300–600)")
    if "/collections/" in final_url and "/products/" not in final_url and words < 200:
        add("high", f"Collection page has ~{words} words of text (add intro + buying guide)")
    if imgs and len(missing_alt) / len(imgs) > 0.3:
        add("medium", f"{len(missing_alt)}/{len(imgs)} images missing alt text")
    if "/products/" in final_url and prod_issues is None:
        add("high", "No Product schema found")
    for i in (prod_issues or []):
        add("medium", i)
    if "FAQPage" not in types and any(k in text.lower() for k in ("faq", "שאלות נפוצות", "שאלות ותשובות")):
        add("low", "FAQ text present but no FAQPage schema")
    if "BreadcrumbList" not in types:
        add("low", "No BreadcrumbList schema")
    if collection_nested:
        add("low", f"{len(collection_nested)} internal links use /collections/.../products/ URLs (link to /products/ directly)")
    if generic_anchors:
        add("low", f"{len(generic_anchors)} links with generic anchor text")
    if not p.lang:
        add("low", "<html> has no lang attribute")
    if size > 2_500_000:
        add("medium", f"HTML is {size/1e6:.1f} MB (heavy page)")

    return {
        "url": final_url,
        "status": status,
        "html_bytes": size,
        "lang": p.lang,
        "title": title,
        "title_length": len(title),
        "meta_description": desc,
        "meta_description_length": len(desc),
        "meta_robots": robots,
        "canonical": p.canonical,
        "hreflang": p.hreflang,
        "og_title": p.meta.get("og:title", ""),
        "h1": h1s,
        "h2": h2s,
        "h3": h3s[:30],
        "word_count": words,
        "images_total": len(imgs),
        "images_missing_alt": len(missing_alt),
        "images_missing_alt_examples": [i["src"] for i in missing_alt[:5]],
        "schema_types": sorted(set(types)),
        "product_schema_issues": prod_issues,
        "internal_links": len(internal),
        "external_links": len(external),
        "internal_link_sample": internal[:25],
        "findings": findings,
        "text_preview": text[:600],
    }


def print_report(r):
    print(f"\n=== SEO AUDIT: {r['url']} ===")
    print(f"Status: {r['status']} | HTML: {r['html_bytes']/1024:.0f} KB | lang: {r['lang'] or '-'}")
    print(f"\nTitle ({r['title_length']}): {r['title']}")
    print(f"Meta description ({r['meta_description_length']}): {r['meta_description'] or '-'}")
    print(f"Robots: {r['meta_robots'] or '-'} | Canonical: {r['canonical'] or '-'}")
    if r["hreflang"]:
        print("Hreflang: " + ", ".join(f"{h}→{u}" for h, u in r["hreflang"][:8]))
    print(f"\nH1 ({len(r['h1'])}): {r['h1']}")
    print(f"H2 ({len(r['h2'])}): {r['h2'][:12]}")
    print(f"H3 ({len(r['h3'])}): {r['h3'][:12]}")
    print(f"\nWords: {r['word_count']} | Images: {r['images_total']} (missing alt: {r['images_missing_alt']})")
    print(f"Schema types: {', '.join(r['schema_types']) or 'none'}")
    if r["product_schema_issues"]:
        for i in r["product_schema_issues"]:
            print(f"  - {i}")
    print(f"Internal links: {r['internal_links']} | External: {r['external_links']}")
    print("\nFINDINGS:")
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    for f in sorted(r["findings"], key=lambda x: order[x["level"]]):
        print(f"  [{f['level'].upper():8}] {f['msg']}")
    if not r["findings"]:
        print("  none")
    print(f"\nText preview: {r['text_preview'][:300]}...\n")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(1)
    url = args[0]
    if not url.startswith("http"):
        url = "https://" + url
    try:
        result = audit(url)
    except Exception as e:
        print(f"ERROR fetching {url}: {e}")
        sys.exit(2)
    if "--json" in sys.argv:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_report(result)
