# Product SEO Brief: [Product name]

**Store URL:** [url]
**Language / market:** [he-IL / en-US]
**Primary keyword:** [keyword]
**Secondary keywords:** [kw1], [kw2], [kw3], [kw4]
**Competing pages on our site for this keyword:** none / [url – action taken]

---

## Paste into Shopify admin

### Product → Title (H1)
```
[Product name – main attribute/benefit]
```

### Search engine listing → Page title  (NN/60 characters)
```
[SEO title]
```

### Search engine listing → Meta description  (NNN/155 characters)
```
[Meta description]
```

### Search engine listing → URL handle
```
[handle]
```
☐ Existing URL changed → "Create a URL redirect" checked and verified

### Product → Description (HTML)

[Opening paragraph with the primary keyword in the first 100 words]

**Why [audience] choose it**
- [Feature → benefit → why it matters]
- [ ]
- [ ]
- [ ]

**Specifications**

| Spec | Value |
|---|---|
| Material | |
| Dimensions | |
| Weight | |
| Capacity / Size | |
| In the box | |

**How to use** (optional)
[2–4 short steps]

**Who it is for (and who should skip it)**
[2–4 sentences]

**Frequently asked questions**
- **[Question 1]?** [Answer]
- **[Question 2]?** [Answer]
- **[Question 3]?** [Answer]
- **[Question 4]?** [Answer]

**Shipping and returns**
[2–3 lines with links to the policy pages]

Internal links included: [collection], [related product], [blog guide]

### Images

| # | File name (before upload) | Alt text |
|---|---|---|
| 1 (main) | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

---

## Structured data

☐ Product schema present and valid (Rich Results Test)
☐ FAQPage JSON-LD added (below)
☐ BreadcrumbList present

```json
[FAQPage JSON-LD]
```

---

## Follow-up

- Internal links to add from: [collection page], [blog article], [related product]
- Blog article to support this product: [working title – keyword]
- Check in Search Console in 4 weeks: impressions and position for "[primary keyword]"
