# סקיל SEO לאיקומרס (Shopify וכל חנות אונליין) – מדריך התקנה

הסקיל הזה מלמד את Claude לעבוד כמומחה קידום אורגני לחנויות איקומרס: אופטימיזציה של דפי מוצר, דפי קטגוריה (קולקשנים), מחקר מילות מפתח בחינם, SEO טכני לשופיפיי, סכמה (Structured Data), תוכן לבלוג שמביא תנועה למוצרים, וסקירה חודשית לפי Search Console.

הוא עובד בעברית ובאנגלית: אם החנות בעברית, Claude יכתוב כותרות, תיאורים ומילות מפתח בעברית טבעית. אם החנות באנגלית, הוא יכתוב אנגלית.

---

## מה יש בתיקייה

```
ecommerce-seo/
├── SKILL.md                    ← ההוראות הראשיות ל-Claude (7 תהליכי עבודה)
├── scripts/
│   ├── seo_audit.py            ← אודיט של כל כתובת URL (כותרת, מטא, H1, תמונות, סכמה, קישורים)
│   └── keyword_suggest.py      ← הרחבת מילת מפתח דרך ההשלמה האוטומטית של גוגל (עברית/אנגלית)
├── references/
│   ├── product-page-checklist.md   ← צ'קליסט מלא לדף מוצר + מבנה תיאור
│   ├── copy-templates.md           ← נוסחאות לכותרת SEO, מטא, H1, alt, עם דוגמאות בעברית ובאנגלית
│   ├── collection-pages.md         ← דפי קולקשן/קטגוריה, כפילויות של פילטרים ותגיות
│   ├── keyword-research.md         ← מחקר מילות מפתח בלי כלים בתשלום
│   ├── shopify-technical-seo.md    ← SEO טכני לשופיפיי (+ הערות ל-WooCommerce ו-Wix)
│   ├── schema-templates.md         ← תבניות JSON-LD מוכנות (Product, FAQ, Breadcrumb, Article)
│   ├── content-strategy.md         ← אשכולות תוכן, מבנה מאמר, קישורים פנימיים, GEO
│   └── monthly-audit.md            ← סקירה חודשית לפי Search Console
└── assets/
    └── product-seo-brief-template.md ← תבנית התוצר לכל מוצר (להעתקה לשופיפיי)
```

---

## התקנה

### אפשרות 1: Claude Code (טרמינל / אפליקציית Desktop, לשונית Code)

1. חלצו את קובץ ה-ZIP.
2. העתיקו את התיקייה `ecommerce-seo` לאחת מהתיקיות הבאות:
   - **לכל הפרויקטים שלכם:** `~/.claude/skills/ecommerce-seo`
   - **לפרויקט אחד בלבד:** `<תיקיית הפרויקט>/.claude/skills/ecommerce-seo`

   ב-Mac/Linux, פקודה אחת שעושה את זה (מתוך התיקייה שבה חילצתם):
   ```bash
   mkdir -p ~/.claude/skills && cp -R ecommerce-seo ~/.claude/skills/
   ```
   ב-Windows (PowerShell):
   ```powershell
   New-Item -ItemType Directory -Force "$env:USERPROFILE\.claude\skills" | Out-Null; Copy-Item -Recurse ecommerce-seo "$env:USERPROFILE\.claude\skills\"
   ```
3. פתחו שיחה חדשה ב-Claude Code. הסקיל נטען אוטומטית כשמבקשים משהו שקשור ל-SEO של חנות, או ידנית עם `/ecommerce-seo`.

### אפשרות 2: אפליקציית Claude (Desktop / Web) – Skills

1. באפליקציה: **Settings → Capabilities → Skills** (או Customize → Skills, תלוי בגרסה).
2. לחצו **Upload skill** והעלו את קובץ ה-ZIP `ecommerce-seo.zip` כמו שהוא (לא לחלץ).
3. ודאו שהסקיל מופעל (toggle ירוק). מעכשיו הוא זמין בכל שיחה.

> אם אינכם רואים את האפשרות Skills, ודאו שהפעלתם **Code execution / File creation** תחת Capabilities. הסקיל זמין בתוכניות Pro / Max / Team / Enterprise.

### אפשרות 3: Cowork

בלשונית Cowork: **Skills → Add skill → Upload ZIP**, או שימו את התיקייה בתיקיית ה-skills של ה-Cowork שלכם.

---

## איך משתמשים – דוגמאות לבקשות

העתיקו והתאימו:

**אופטימיזציה של דף מוצר**
```
תעשה אופטימיזציית SEO לדף המוצר הזה: https://www.החנות-שלי.co.il/products/xxx
המילה הראשית היא "בקבוק תרמי 1 ליטר". תן לי כותרת SEO, מטא, H1, תיאור מלא, alt לתמונות ו-FAQ.
```

**מחקר מילות מפתח**
```
תעשה לי מחקר מילות מפתח בעברית למוצר "מכונת קפה קפסולות". תמיין לפי כוונת חיפוש ותגיד לאיזה סוג דף כל מילה מתאימה.
```

**דף קולקשן**
```
הקולקשן "מתנות לגבר" שלי ריק מתוכן. תכתוב לי טקסט פתיחה, מדריך קנייה, FAQ וכותרות SEO.
```

**אודיט טכני**
```
תריץ אודיט SEO טכני על החנות שלי: דף הבית, קולקשן אחד ושני מוצרים. [כתובות]. תן לי רשימת תיקונים לפי סדר עדיפות.
```

**תוכן לבלוג**
```
תבנה לי תוכנית תוכן של 15 מאמרים סביב הקולקשן "נעלי ריצה", עם מילת מפתח לכל מאמר ולאיזה מוצר הוא מקשר.
```

**סקירה חודשית**
```
הנה הייצוא של Queries ו-Pages מ-Search Console ל-28 יום האחרונים [להדביק / לצרף CSV]. תעשה לי סקירה חודשית ותן 5 פעולות לחודש הקרוב.
```

**סכמה**
```
תבדוק אם יש לי Product schema תקין בדף הזה ותכין לי FAQPage JSON-LD למוצר.
```

---

## הרצת הסקריפטים ידנית (לא חובה)

הסקריפטים משתמשים רק בספריות המובנות של Python 3, בלי התקנות.

```bash
python3 ecommerce-seo/scripts/seo_audit.py https://www.example.com/products/xxx
python3 ecommerce-seo/scripts/keyword_suggest.py "בקבוק תרמי" --lang he --country il
```

---

## עקרונות שהסקיל אוכף

1. עמוד אחד = מילת מפתח ראשית אחת. קולקשן לוקח את המילה הרחבה, מוצר את הספציפית, בלוג את השאלות.
2. כוונת חיפוש קודם: שאלות "איך לבחור" הולכות לבלוג, לא לדף מוצר.
3. תוכן ייחודי לכל מוצר. תיאורים מועתקים מהספק לא מדורגים.
4. תיקונים טכניים לפני כמות תוכן.
5. כל המלצה נמדדת ב-Google Search Console.

בהצלחה,
Ecommerce Club
